# Add project specific ProGuard rules here.
-keep class com.wakeup.app.data.model.** { *; }
