package com.wakeup.app

import android.app.Application
import com.wakeup.app.data.repository.AlarmRepository
import com.wakeup.app.service.AlarmNotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

class AlarmApplication : Application() {

    lateinit var repository: AlarmRepository
        private set

    private val appScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    override fun onCreate() {
        super.onCreate()
        AlarmNotificationHelper.ensureChannels(this)
        repository = AlarmRepository(this)
        appScope.launch {
            repository.rescheduleAllEnabledAlarms()
        }
    }
}
