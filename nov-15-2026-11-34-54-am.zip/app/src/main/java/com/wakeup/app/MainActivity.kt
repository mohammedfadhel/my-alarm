package com.wakeup.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.wakeup.app.ui.screens.AlarmEditScreen
import com.wakeup.app.ui.screens.AlarmListScreen
import com.wakeup.app.ui.screens.SettingsAndPermissionsScreen
import com.wakeup.app.ui.theme.MonabihiTheme
import com.wakeup.app.ui.viewmodel.AlarmViewModel

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            MonabihiTheme {
                val navController = rememberNavController()
                val viewModel: AlarmViewModel = viewModel()
                val shouldShowFirstLaunch by viewModel.shouldShowFirstLaunchCheck.collectAsStateWithLifecycle()

                LaunchedEffect(Unit) {
                    viewModel.rescheduleAll()
                    viewModel.refreshPermissions()
                }

                LaunchedEffect(shouldShowFirstLaunch) {
                    if (shouldShowFirstLaunch) {
                        viewModel.markFirstLaunchCheckConsumed()
                        navController.navigate(ROUTE_SETTINGS) {
                            launchSingleTop = true
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = ROUTE_HOME
                ) {
                    composable(ROUTE_HOME) {
                        AlarmListScreen(
                            viewModel = viewModel,
                            onAddAlarm = {
                                navController.navigate("alarm_edit/0")
                            },
                            onEditAlarm = { alarmId ->
                                navController.navigate("alarm_edit/$alarmId")
                            },
                            onOpenSettings = {
                                navController.navigate(ROUTE_SETTINGS)
                            }
                        )
                    }

                    composable(
                        route = "alarm_edit/{alarmId}",
                        arguments = listOf(
                            navArgument("alarmId") {
                                type = NavType.LongType
                                defaultValue = 0L
                            }
                        )
                    ) { backStackEntry ->
                        val alarmId = backStackEntry.arguments?.getLong("alarmId") ?: 0L
                        AlarmEditScreen(
                            alarmId = alarmId,
                            viewModel = viewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(ROUTE_SETTINGS) {
                        SettingsAndPermissionsScreen(
                            viewModel = viewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }
                }
            }
        }
    }

    companion object {
        private const val ROUTE_HOME = "alarm_list"
        private const val ROUTE_SETTINGS = "settings"
    }
}
