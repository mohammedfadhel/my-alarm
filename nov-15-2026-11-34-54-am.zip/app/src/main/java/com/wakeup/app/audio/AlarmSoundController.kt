package com.wakeup.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.media.MediaPlayer
import android.net.Uri
import com.wakeup.app.data.model.ToneType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.max
import kotlin.math.roundToInt

/**
 * Manages alarm playback on STREAM_ALARM with AudioFocus, volume override/restore,
 * 20-second gradual volume fade-in, custom audio URI playback, and automatic fallback
 * to the built-in AudioTrack tone if the custom file fails or is unavailable.
 */
class AlarmSoundController(private val context: Context) {

    private val audioManager = context.getSystemService(AudioManager::class.java)
    private val toneEngine = ToneGeneratorEngine()
    private var mediaPlayer: MediaPlayer? = null
    private var focusRequest: AudioFocusRequest? = null
    private var previousAlarmVolume: Int? = null
    private var gradualJob: Job? = null
    private var isPlayingCustomUri = false

    fun start(
        scope: CoroutineScope,
        toneType: ToneType,
        toneUri: String?,
        volumePercent: Int,
        gradualVolume: Boolean
    ) {
        stop()

        requestAlarmAudioFocus()
        applyEmergencyAlarmVolume(volumePercent)

        val initialGain = if (gradualVolume) 0.08f else 1.0f

        if (toneType == ToneType.CUSTOM_URI && !toneUri.isNullOrBlank()) {
            val startedCustom = tryStartCustomUri(toneUri, initialGain)
            if (!startedCustom) {
                isPlayingCustomUri = false
                toneEngine.start(ToneType.CLASSIC_BELL, initialGain)
            }
        } else {
            isPlayingCustomUri = false
            toneEngine.start(toneType, initialGain)
        }

        if (gradualVolume) {
            gradualJob = scope.launch(Dispatchers.Default) {
                val totalSteps = 200 // 200 * 100ms = 20 seconds
                for (step in 1..totalSteps) {
                    if (!isActive) break
                    delay(100L)
                    val progress = step.toFloat() / totalSteps
                    val gain = 0.08f + (0.92f * progress)
                    setCurrentGain(gain)
                }
            }
        }
    }

    private fun tryStartCustomUri(uriString: String, initialGain: Float): Boolean {
        return try {
            val uri = Uri.parse(uriString)
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(context, uri)
                isLooping = true
                setOnErrorListener { mp, _, _ ->
                    try {
                        mp.reset()
                        mp.release()
                    } catch (_: Exception) {
                    }
                    if (mediaPlayer === mp) {
                        mediaPlayer = null
                    }
                    isPlayingCustomUri = false
                    toneEngine.start(ToneType.CLASSIC_BELL, 1.0f)
                    true
                }
                prepare()
                val clamped = initialGain.coerceIn(0.02f, 1.0f)
                setVolume(clamped, clamped)
                start()
            }
            mediaPlayer = player
            isPlayingCustomUri = true
            true
        } catch (_: Exception) {
            releaseMediaPlayer()
            false
        }
    }

    private fun setCurrentGain(gain: Float) {
        val clamped = gain.coerceIn(0.02f, 1.0f)
        if (isPlayingCustomUri) {
            try {
                mediaPlayer?.setVolume(clamped, clamped)
            } catch (_: IllegalStateException) {
            }
        } else {
            toneEngine.setGain(clamped)
        }
    }

    private fun applyEmergencyAlarmVolume(volumePercent: Int) {
        val manager = audioManager ?: return
        try {
            val current = manager.getStreamVolume(AudioManager.STREAM_ALARM)
            previousAlarmVolume = current
            val maxVol = manager.getStreamMaxVolume(AudioManager.STREAM_ALARM).coerceAtLeast(1)
            val safePercent = volumePercent.coerceIn(20, 100)
            // Emergency safety: if stream volume is 0 or lower than desired, force it up.
            val desired = max(1, ((maxVol * safePercent) / 100f).roundToInt()).coerceAtMost(maxVol)
            val target = if (current == 0) max(desired, (maxVol * 0.7f).roundToInt().coerceAtLeast(1)) else desired
            manager.setStreamVolume(AudioManager.STREAM_ALARM, target, 0)
        } catch (_: SecurityException) {
            // Some OEMs restrict volume changes under specific DND modes
        }
    }

    private fun requestAlarmAudioFocus() {
        val manager = audioManager ?: return
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()
        val request = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
            .setAudioAttributes(attributes)
            .setAcceptsDelayedFocusGain(false)
            .setOnAudioFocusChangeListener { }
            .build()
        focusRequest = request
        manager.requestAudioFocus(request)
    }

    fun stop() {
        gradualJob?.cancel()
        gradualJob = null

        toneEngine.stop()
        releaseMediaPlayer()
        isPlayingCustomUri = false

        val manager = audioManager
        val savedVolume = previousAlarmVolume
        previousAlarmVolume = null
        if (manager != null && savedVolume != null) {
            try {
                manager.setStreamVolume(AudioManager.STREAM_ALARM, savedVolume, 0)
            } catch (_: SecurityException) {
            }
        }

        val req = focusRequest
        focusRequest = null
        if (manager != null && req != null) {
            manager.abandonAudioFocusRequest(req)
        }
    }

    private fun releaseMediaPlayer() {
        val player = mediaPlayer ?: return
        mediaPlayer = null
        try {
            if (player.isPlaying) {
                player.stop()
            }
        } catch (_: IllegalStateException) {
        }
        try {
            player.reset()
        } catch (_: Exception) {
        }
        try {
            player.release()
        } catch (_: Exception) {
        }
    }
}
