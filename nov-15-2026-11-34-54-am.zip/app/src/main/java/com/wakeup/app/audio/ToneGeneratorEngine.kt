package com.wakeup.app.audio

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import com.wakeup.app.data.model.ToneType
import kotlin.math.PI
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Generates seamless-looping, high-loudness, distortion-free alarm tones in PCM-16
 * using AudioTrack in MODE_STATIC on USAGE_ALARM / CONTENT_TYPE_MUSIC.
 */
class ToneGeneratorEngine {

    private var audioTrack: AudioTrack? = null
    private val lock = Any()

    fun start(toneType: ToneType, initialGain: Float = 1.0f) {
        stop()
        val effectiveTone = if (toneType == ToneType.CUSTOM_URI) ToneType.CLASSIC_BELL else toneType
        val samples = generateWaveform(effectiveTone)
        val bufferSizeBytes = samples.size * 2

        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        val format = AudioFormat.Builder()
            .setSampleRate(SAMPLE_RATE)
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()

        val track = AudioTrack(
            attributes,
            format,
            bufferSizeBytes,
            AudioTrack.MODE_STATIC,
            AudioManager.AUDIO_SESSION_ID_GENERATE
        )

        synchronized(lock) {
            if (track.state != AudioTrack.STATE_INITIALIZED) {
                track.release()
                return
            }
            track.write(samples, 0, samples.size)
            track.setLoopPoints(0, samples.size, -1)
            val clampedGain = initialGain.coerceIn(0.02f, 1.0f)
            track.setVolume(clampedGain)
            track.play()
            audioTrack = track
        }
    }

    fun setGain(gain: Float) {
        synchronized(lock) {
            val track = audioTrack ?: return
            if (track.state == AudioTrack.STATE_INITIALIZED) {
                track.setVolume(gain.coerceIn(0.02f, 1.0f))
            }
        }
    }

    fun stop() {
        synchronized(lock) {
            val track = audioTrack ?: return
            audioTrack = null
            try {
                if (track.playState == AudioTrack.PLAYSTATE_PLAYING) {
                    track.pause()
                    track.flush()
                    track.stop()
                }
            } catch (_: IllegalStateException) {
                // Already stopped
            } finally {
                track.release()
            }
        }
    }

    private fun generateWaveform(toneType: ToneType): ShortArray {
        return when (toneType) {
            ToneType.CLASSIC_BELL -> buildClassicBell()
            ToneType.MORNING_ROOSTER -> buildMorningRooster()
            ToneType.FAST_PULSES -> buildFastPulses()
            ToneType.RISING_WAVES -> buildRisingWaves()
            ToneType.SHARP_ALARM -> buildSharpAlarm()
            ToneType.MORNING_FLUTE -> buildMorningFlute()
            ToneType.CUSTOM_URI -> buildClassicBell()
        }
    }

    /**
     * 1. جرس كلاسيكي: Metallic twin-bell ring with rapid hammer modulation.
     * Loop length: 2.8 seconds.
     */
    private fun buildClassicBell(): ShortArray {
        val durationSec = 2.8
        val count = (SAMPLE_RATE * durationSec).toInt()
        val raw = DoubleArray(count)
        for (i in 0 until count) {
            val t = i.toDouble() / SAMPLE_RATE
            val burst = when {
                t < 0.85 -> envelope(t, 0.85, 0.015, 0.04)
                t in 1.15..2.00 -> envelope(t - 1.15, 0.85, 0.015, 0.04)
                else -> 0.0
            }
            if (burst > 0.0) {
                val hammer = 0.55 + 0.45 * sin(2.0 * PI * 24.0 * t)
                val bellBody =
                    0.50 * sin(2.0 * PI * 1180.0 * t) +
                        0.38 * sin(2.0 * PI * 2360.0 * t) +
                        0.26 * sin(2.0 * PI * 3540.0 * t) +
                        0.15 * sin(2.0 * PI * 4720.0 * t)
                raw[i] = burst * hammer * bellBody
            }
        }
        return normalizeToPcm16(raw)
    }

    /**
     * 2. ديك الصباح: Energetic rising morning chirps / crowing glissandos.
     * Loop length: 2.4 seconds.
     */
    private fun buildMorningRooster(): ShortArray {
        val durationSec = 2.4
        val count = (SAMPLE_RATE * durationSec).toInt()
        val raw = DoubleArray(count)

        data class Chirp(val start: Double, val len: Double, val f0: Double, val f1: Double)
        val chirps = listOf(
            Chirp(0.05, 0.22, 620.0, 1280.0),
            Chirp(0.32, 0.22, 740.0, 1520.0),
            Chirp(0.60, 0.30, 880.0, 1880.0),
            Chirp(0.96, 0.65, 1760.0, 1180.0)
        )

        for (chirp in chirps) {
            val startIdx = (chirp.start * SAMPLE_RATE).toInt()
            val lenSamples = (chirp.len * SAMPLE_RATE).toInt()
            var phase = 0.0
            for (k in 0 until lenSamples) {
                val idx = startIdx + k
                if (idx >= count) break
                val localT = k.toDouble() / SAMPLE_RATE
                val progress = k.toDouble() / lenSamples
                val freq = chirp.f0 + (chirp.f1 - chirp.f0) * progress
                phase += 2.0 * PI * freq / SAMPLE_RATE
                val env = envelope(localT, chirp.len, 0.015, 0.035)
                val sig = 0.65 * sin(phase) + 0.30 * sin(2.0 * phase) + 0.15 * sin(3.0 * phase)
                raw[idx] += env * sig
            }
        }
        return normalizeToPcm16(raw)
    }

    /**
     * 3. نبضات سريعة: Crisp urgent rhythmic pulses (double-beeps).
     * Loop length: 1.6 seconds.
     */
    private fun buildFastPulses(): ShortArray {
        val durationSec = 1.6
        val count = (SAMPLE_RATE * durationSec).toInt()
        val raw = DoubleArray(count)
        val pulseStarts = doubleArrayOf(0.04, 0.22, 0.40, 0.84, 1.02, 1.20)
        val pulseLen = 0.12

        for (pIndex in pulseStarts.indices) {
            val start = pulseStarts[pIndex]
            val baseFreq = if (pIndex % 3 == 2) 1318.5 else 987.77
            val startIdx = (start * SAMPLE_RATE).toInt()
            val lenSamples = (pulseLen * SAMPLE_RATE).toInt()
            for (k in 0 until lenSamples) {
                val idx = startIdx + k
                if (idx >= count) break
                val localT = k.toDouble() / SAMPLE_RATE
                val env = envelope(localT, pulseLen, 0.008, 0.018)
                val sig =
                    0.65 * sin(2.0 * PI * baseFreq * localT) +
                        0.28 * sin(2.0 * PI * baseFreq * 2.0 * localT) +
                        0.15 * sin(2.0 * PI * baseFreq * 3.0 * localT)
                raw[idx] += env * sig
            }
        }
        return normalizeToPcm16(raw)
    }

    /**
     * 4. أمواج صاعدة: Slowly rising melodic arpeggio with rich chime harmonics.
     * Loop length: 3.2 seconds.
     */
    private fun buildRisingWaves(): ShortArray {
        val durationSec = 3.2
        val count = (SAMPLE_RATE * durationSec).toInt()
        val raw = DoubleArray(count)
        // C5, E5, G5, B5, C6, E6, G6
        val notes = doubleArrayOf(523.25, 659.25, 783.99, 987.77, 1046.50, 1318.51, 1567.98)
        val step = 0.36
        val noteDur = 0.62

        for (nIdx in notes.indices) {
            val freq = notes[nIdx]
            val start = 0.08 + nIdx * step
            val startIdx = (start * SAMPLE_RATE).toInt()
            val lenSamples = (noteDur * SAMPLE_RATE).toInt()
            val swell = 0.55 + 0.45 * (nIdx.toDouble() / (notes.size - 1))
            for (k in 0 until lenSamples) {
                val idx = (startIdx + k) % count
                val localT = k.toDouble() / SAMPLE_RATE
                val env = envelope(localT, noteDur, 0.02, 0.22) * swell
                val sig =
                    0.68 * sin(2.0 * PI * freq * localT) +
                        0.24 * sin(2.0 * PI * freq * 2.0 * localT) +
                        0.12 * sin(2.0 * PI * freq * 3.0 * localT)
                raw[idx] += env * sig
            }
        }
        return normalizeToPcm16(raw)
    }

    /**
     * 5. إنذار حاد: High-urgency dual-tone emergency siren alert.
     * Loop length: 2.0 seconds.
     */
    private fun buildSharpAlarm(): ShortArray {
        val durationSec = 2.0
        val count = (SAMPLE_RATE * durationSec).toInt()
        val raw = DoubleArray(count)
        val segments = listOf(
            Triple(0.02, 0.38, 1760.0),
            Triple(0.42, 0.38, 2349.32),
            Triple(0.84, 0.38, 1760.0),
            Triple(1.24, 0.38, 2349.32)
        )
        for ((start, len, freq) in segments) {
            val startIdx = (start * SAMPLE_RATE).toInt()
            val lenSamples = (len * SAMPLE_RATE).toInt()
            for (k in 0 until lenSamples) {
                val idx = startIdx + k
                if (idx >= count) break
                val localT = k.toDouble() / SAMPLE_RATE
                val env = envelope(localT, len, 0.010, 0.015)
                val mod = 0.8 + 0.2 * sin(2.0 * PI * 14.0 * localT)
                val sig =
                    0.60 * sin(2.0 * PI * freq * localT) +
                        0.32 * sin(2.0 * PI * freq * 1.5 * localT) +
                        0.20 * sin(2.0 * PI * freq * 2.0 * localT)
                raw[idx] += env * mod * sig
            }
        }
        return normalizeToPcm16(raw)
    }

    /**
     * 6. ناي الصباح: Soft melodic Eastern flute phrase that builds in intensity.
     * Loop length: 4.0 seconds.
     */
    private fun buildMorningFlute(): ShortArray {
        val durationSec = 4.0
        val count = (SAMPLE_RATE * durationSec).toInt()
        val raw = DoubleArray(count)
        // Warm Hijaz-flavored motif: D5, Eb5, F#5, G5, A5, G5, F#5, D5
        val notes = listOf(
            Triple(0.05, 0.42, 587.33),
            Triple(0.50, 0.40, 622.25),
            Triple(0.95, 0.50, 739.99),
            Triple(1.50, 0.48, 783.99),
            Triple(2.05, 0.55, 880.00),
            Triple(2.65, 0.42, 783.99),
            Triple(3.10, 0.40, 739.99),
            Triple(3.52, 0.42, 587.33)
        )

        for (index in notes.indices) {
            val (start, len, freq) = notes[index]
            val startIdx = (start * SAMPLE_RATE).toInt()
            val lenSamples = (len * SAMPLE_RATE).toInt()
            // Starts softer in first half, louder in second half
            val phraseGain = if (index < 4) 0.58 else 1.0
            for (k in 0 until lenSamples) {
                val idx = startIdx + k
                if (idx >= count) break
                val localT = k.toDouble() / SAMPLE_RATE
                val env = envelope(localT, len, 0.04, 0.08) * phraseGain
                val vibrato = 1.0 + 0.006 * sin(2.0 * PI * 5.2 * localT)
                val f = freq * vibrato
                val sig =
                    0.75 * sin(2.0 * PI * f * localT) +
                        0.18 * sin(2.0 * PI * f * 2.0 * localT) +
                        0.07 * sin(2.0 * PI * f * 3.0 * localT)
                raw[idx] += env * sig
            }
        }
        return normalizeToPcm16(raw)
    }

    private fun envelope(t: Double, duration: Double, attack: Double, release: Double): Double {
        if (t < 0.0 || t > duration) return 0.0
        val att = if (attack > 0.0 && t < attack) t / attack else 1.0
        val rel = if (release > 0.0 && t > duration - release) {
            ((duration - t) / release).coerceAtLeast(0.0)
        } else {
            1.0
        }
        return min(att, rel)
    }

    private fun normalizeToPcm16(raw: DoubleArray): ShortArray {
        // Apply short loop-edge fade (4ms) to guarantee zero click at loop wrap
        val fadeSamples = (SAMPLE_RATE * 0.004).toInt().coerceAtMost(raw.size / 4)
        for (i in 0 until fadeSamples) {
            val factor = i.toDouble() / fadeSamples
            raw[i] *= factor
            raw[raw.size - 1 - i] *= factor
        }

        var peak = 0.0
        for (v in raw) {
            val absV = kotlin.math.abs(v)
            if (absV > peak) peak = absV
        }
        val scale = if (peak > 1e-6) 0.94 / peak else 1.0

        val out = ShortArray(raw.size)
        for (i in raw.indices) {
            // Soft limiting via tanh for maximum perceived loudness without harsh clipping
            val normalized = tanh(raw[i] * scale * 1.15)
            out[i] = (normalized * Short.MAX_VALUE).toInt()
                .coerceIn(Short.MIN_VALUE.toInt(), Short.MAX_VALUE.toInt())
                .toShort()
        }
        return out
    }

    companion object {
        private const val SAMPLE_RATE = 44100
    }
}
