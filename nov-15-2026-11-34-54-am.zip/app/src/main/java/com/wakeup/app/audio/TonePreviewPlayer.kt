package com.wakeup.app.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import com.wakeup.app.data.model.ToneType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Lightweight preview player for the Add/Edit Alarm screen so the user can listen
 * to each built-in tone or custom audio file before saving.
 */
class TonePreviewPlayer(private val context: Context) {

    private val toneEngine = ToneGeneratorEngine()
    private var mediaPlayer: MediaPlayer? = null

    private val _playingTone = MutableStateFlow<ToneType?>(null)
    val playingTone: StateFlow<ToneType?> = _playingTone.asStateFlow()

    fun togglePreview(toneType: ToneType, customUri: String? = null, volumePercent: Int = 100) {
        if (_playingTone.value == toneType) {
            stop()
            return
        }
        stop()

        val gain = (volumePercent.coerceIn(10, 100) / 100f)
        if (toneType == ToneType.CUSTOM_URI) {
            if (customUri.isNullOrBlank()) return
            val started = tryStartCustomPreview(customUri, gain)
            if (started) {
                _playingTone.value = ToneType.CUSTOM_URI
            } else {
                toneEngine.start(ToneType.CLASSIC_BELL, gain)
                _playingTone.value = ToneType.CLASSIC_BELL
            }
        } else {
            toneEngine.start(toneType, gain)
            _playingTone.value = toneType
        }
    }

    private fun tryStartCustomPreview(uriString: String, gain: Float): Boolean {
        return try {
            val player = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )
                setDataSource(context, Uri.parse(uriString))
                isLooping = true
                setOnErrorListener { _, _, _ ->
                    stop()
                    true
                }
                prepare()
                setVolume(gain, gain)
                start()
            }
            mediaPlayer = player
            true
        } catch (_: Exception) {
            releaseMediaPlayer()
            false
        }
    }

    fun updateVolume(volumePercent: Int) {
        val gain = (volumePercent.coerceIn(10, 100) / 100f)
        if (_playingTone.value == ToneType.CUSTOM_URI) {
            try {
                mediaPlayer?.setVolume(gain, gain)
            } catch (_: IllegalStateException) {
            }
        } else if (_playingTone.value != null) {
            toneEngine.setGain(gain)
        }
    }

    fun stop() {
        toneEngine.stop()
        releaseMediaPlayer()
        _playingTone.value = null
    }

    private fun releaseMediaPlayer() {
        val player = mediaPlayer ?: return
        mediaPlayer = null
        try {
            if (player.isPlaying) player.stop()
        } catch (_: IllegalStateException) {
        }
        try {
            player.release()
        } catch (_: Exception) {
        }
    }
}
