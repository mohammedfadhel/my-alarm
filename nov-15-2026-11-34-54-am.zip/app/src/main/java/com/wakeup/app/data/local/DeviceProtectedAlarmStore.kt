package com.wakeup.app.data.local

import android.content.Context
import android.content.SharedPreferences

data class CachedAlarmSchedule(
    val id: Long,
    val hour: Int,
    val minute: Int,
    val daysMask: Int
)

/**
 * Stores lightweight scheduling data in Device Protected Storage so LOCKED_BOOT_COMPLETED
 * can reschedule alarms safely before the user unlocks the device.
 */
class DeviceProtectedAlarmStore(context: Context) {
    private val prefs: SharedPreferences by lazy {
        val deviceContext = context.createDeviceProtectedStorageContext()
        deviceContext.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    }

    fun saveEnabledAlarmsSnapshot(items: List<CachedAlarmSchedule>) {
        val serialized = items.joinToString(separator = ";") {
            "${it.id},${it.hour},${it.minute},${it.daysMask}"
        }
        prefs.edit().putString(KEY_ENABLED_SNAPSHOT, serialized).apply()
    }

    fun getEnabledAlarmsSnapshot(): List<CachedAlarmSchedule> {
        val raw = prefs.getString(KEY_ENABLED_SNAPSHOT, null).orEmpty()
        if (raw.isBlank()) return emptyList()
        return raw.split(";").mapNotNull { entry ->
            val parts = entry.split(",")
            if (parts.size != 4) return@mapNotNull null
            val id = parts[0].toLongOrNull() ?: return@mapNotNull null
            val hour = parts[1].toIntOrNull() ?: return@mapNotNull null
            val minute = parts[2].toIntOrNull() ?: return@mapNotNull null
            val mask = parts[3].toIntOrNull() ?: return@mapNotNull null
            CachedAlarmSchedule(id, hour, minute, mask)
        }
    }

    fun setSnoozeTarget(alarmId: Long, triggerAtMillis: Long) {
        val current = getAllSnoozeTargets().toMutableMap()
        current[alarmId] = triggerAtMillis
        saveSnoozeMap(current)
    }

    fun clearSnoozeTarget(alarmId: Long) {
        val current = getAllSnoozeTargets().toMutableMap()
        if (current.remove(alarmId) != null) {
            saveSnoozeMap(current)
        }
    }

    fun getSnoozeTarget(alarmId: Long): Long? {
        val value = getAllSnoozeTargets()[alarmId] ?: return null
        return if (value > 0L) value else null
    }

    fun getAllSnoozeTargets(): Map<Long, Long> {
        val raw = prefs.getString(KEY_SNOOZE_TARGETS, null).orEmpty()
        if (raw.isBlank()) return emptyMap()
        val result = linkedMapOf<Long, Long>()
        raw.split(";").forEach { entry ->
            val parts = entry.split(":")
            if (parts.size == 2) {
                val id = parts[0].toLongOrNull()
                val ts = parts[1].toLongOrNull()
                if (id != null && ts != null && ts > 0L) {
                    result[id] = ts
                }
            }
        }
        return result
    }

    private fun saveSnoozeMap(map: Map<Long, Long>) {
        val serialized = map.entries.joinToString(";") { "${it.key}:${it.value}" }
        prefs.edit().putString(KEY_SNOOZE_TARGETS, serialized).apply()
    }

    fun isFirstLaunchPermissionCheckShown(): Boolean {
        return prefs.getBoolean(KEY_FIRST_LAUNCH_CHECK_SHOWN, false)
    }

    fun markFirstLaunchPermissionCheckShown() {
        prefs.edit().putBoolean(KEY_FIRST_LAUNCH_CHECK_SHOWN, true).apply()
    }

    companion object {
        private const val PREFS_NAME = "monabihi_device_protected_prefs"
        private const val KEY_ENABLED_SNAPSHOT = "enabled_alarms_snapshot"
        private const val KEY_SNOOZE_TARGETS = "active_snooze_targets"
        private const val KEY_FIRST_LAUNCH_CHECK_SHOWN = "first_launch_permission_check_shown"
    }
}
