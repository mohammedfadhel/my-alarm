package com.wakeup.app.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "alarms")
data class Alarm(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0L,
    val hour: Int,
    val minute: Int,
    val label: String = "",
    val daysMask: Int = 0,
    val enabled: Boolean = true,
    val toneType: String = ToneType.CLASSIC_BELL.name,
    val toneUri: String? = null,
    val volumePercent: Int = 100,
    val gradualVolume: Boolean = false,
    val vibrate: Boolean = true,
    val snoozeMinutes: Int = 5,
    val snoozeMaxCount: Int = 3,
    val mathChallenge: Boolean = false,
    val snoozeCount: Int = 0
)
