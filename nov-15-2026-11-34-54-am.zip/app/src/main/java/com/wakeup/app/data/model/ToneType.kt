package com.wakeup.app.data.model

enum class ToneType(
    val arabicTitle: String,
    val arabicDescription: String
) {
    CLASSIC_BELL("جرس كلاسيكي", "رنين معدني قوي وواضح"),
    MORNING_ROOSTER("ديك الصباح", "نغمات صاعدة نشيطة لإيقاظ سريع"),
    FAST_PULSES("نبضات سريعة", "نبضات إيقاعية متلاحقة عالية الوضوح"),
    RISING_WAVES("أمواج صاعدة", "تدرّج لحني صاعد متناغم"),
    SHARP_ALARM("إنذار حاد", "نغمة طوارئ ثنائية النبرة عالية القوة"),
    MORNING_FLUTE("ناي الصباح", "لحن هادئ في البداية يزداد قوة"),
    CUSTOM_URI("ملف صوتي من الهاتف", "اختيار ملف صوتي من ذاكرة الجهاز");

    companion object {
        val builtInTones: List<ToneType> = listOf(
            CLASSIC_BELL,
            MORNING_ROOSTER,
            FAST_PULSES,
            RISING_WAVES,
            SHARP_ALARM,
            MORNING_FLUTE
        )

        fun fromName(name: String?): ToneType {
            return entries.firstOrNull { it.name == name } ?: CLASSIC_BELL
        }
    }
}
