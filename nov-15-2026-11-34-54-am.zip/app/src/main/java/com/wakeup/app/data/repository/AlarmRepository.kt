package com.wakeup.app.data.repository

import android.content.Context
import com.wakeup.app.data.local.AlarmDao
import com.wakeup.app.data.local.AlarmDatabase
import com.wakeup.app.data.local.CachedAlarmSchedule
import com.wakeup.app.data.local.DeviceProtectedAlarmStore
import com.wakeup.app.data.model.Alarm
import com.wakeup.app.scheduler.AlarmScheduler
import kotlinx.coroutines.flow.Flow

class AlarmRepository(context: Context) {
    private val appContext = context.applicationContext
    private val dao: AlarmDao = AlarmDatabase.getInstance(appContext).alarmDao()
    val protectedStore = DeviceProtectedAlarmStore(appContext)
    val scheduler = AlarmScheduler(appContext, protectedStore)

    val allAlarms: Flow<List<Alarm>> = dao.observeAllAlarms()

    suspend fun getAlarmById(id: Long): Alarm? = dao.getAlarmById(id)

    suspend fun getEnabledAlarms(): List<Alarm> = dao.getEnabledAlarms()

    suspend fun saveAlarm(alarm: Alarm): Long {
        val resetAlarm = alarm.copy(snoozeCount = 0)
        val savedId = if (resetAlarm.id == 0L) {
            dao.insert(resetAlarm)
        } else {
            dao.update(resetAlarm)
            resetAlarm.id
        }
        val persisted = resetAlarm.copy(id = savedId)
        protectedStore.clearSnoozeTarget(savedId)
        if (persisted.enabled) {
            scheduler.scheduleAlarm(persisted)
        } else {
            scheduler.cancelAlarm(savedId)
        }
        syncProtectedCache()
        return savedId
    }

    suspend fun toggleAlarmEnabled(alarm: Alarm, enabled: Boolean) {
        val updated = alarm.copy(enabled = enabled, snoozeCount = 0)
        dao.update(updated)
        protectedStore.clearSnoozeTarget(alarm.id)
        if (enabled) {
            scheduler.scheduleAlarm(updated)
        } else {
            scheduler.cancelAlarm(alarm.id)
        }
        syncProtectedCache()
    }

    suspend fun deleteAlarm(alarm: Alarm) {
        scheduler.cancelAlarm(alarm.id)
        dao.delete(alarm)
        syncProtectedCache()
    }

    suspend fun deleteAlarmById(alarmId: Long) {
        scheduler.cancelAlarm(alarmId)
        dao.deleteById(alarmId)
        syncProtectedCache()
    }

    suspend fun handlePrimaryTriggerDatabaseUpdate(alarm: Alarm) {
        if (alarm.daysMask != 0) {
            val reset = alarm.copy(snoozeCount = 0)
            dao.update(reset)
            scheduler.scheduleAlarm(reset)
        } else {
            val disabled = alarm.copy(enabled = false, snoozeCount = 0)
            dao.update(disabled)
        }
        syncProtectedCache()
    }

    suspend fun incrementSnoozeCountAndSchedule(alarmId: Long): Alarm? {
        val current = dao.getAlarmById(alarmId) ?: return null
        val updated = current.copy(snoozeCount = current.snoozeCount + 1)
        dao.update(updated)
        scheduler.scheduleSnooze(updated)
        return updated
    }

    suspend fun resetSnoozeCount(alarmId: Long) {
        dao.updateSnoozeCount(alarmId, 0)
        protectedStore.clearSnoozeTarget(alarmId)
    }

    suspend fun rescheduleAllEnabledAlarms() {
        val enabled = dao.getEnabledAlarms()
        scheduler.rescheduleAll(enabled)
    }

    fun scheduleTestAlarm(): Long {
        return scheduler.scheduleTestAlarm()
    }

    private suspend fun syncProtectedCache() {
        val enabled = dao.getEnabledAlarms()
        protectedStore.saveEnabledAlarmsSnapshot(
            enabled.map { CachedAlarmSchedule(it.id, it.hour, it.minute, it.daysMask) }
        )
    }
}
