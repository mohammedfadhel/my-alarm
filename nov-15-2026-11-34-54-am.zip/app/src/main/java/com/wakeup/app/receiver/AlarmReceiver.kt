package com.wakeup.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.wakeup.app.data.local.DeviceProtectedAlarmStore
import com.wakeup.app.data.model.ToneType
import com.wakeup.app.data.repository.AlarmRepository
import com.wakeup.app.scheduler.AlarmScheduler
import com.wakeup.app.service.AlarmRuntimeState
import com.wakeup.app.service.AlarmService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.time.ZonedDateTime

class AlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action != ACTION_ALARM_TRIGGER && action != ACTION_ALARM_BACKUP_TRIGGER) {
            return
        }

        val alarmId = intent.getLongExtra(EXTRA_ALARM_ID, Long.MIN_VALUE)
        val isSnooze = intent.getBooleanExtra(EXTRA_IS_SNOOZE, false)
        val isTest = intent.getBooleanExtra(EXTRA_IS_TEST, false)
        val isBackup = intent.getBooleanExtra(EXTRA_IS_BACKUP, false) ||
            action == ACTION_ALARM_BACKUP_TRIGGER
        val expectedTrigger = intent.getLongExtra(EXTRA_EXPECTED_TRIGGER, 0L)

        if (!AlarmRuntimeState.tryClaimTrigger(alarmId, expectedTrigger, isBackup)) {
            return
        }

        val powerManager = context.getSystemService(PowerManager::class.java)
        val wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Monabihi:AlarmReceiverWakeLock"
        )?.apply {
            setReferenceCounted(false)
            acquire(20_000L)
        }

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val appContext = context.applicationContext
                if (isTest || alarmId == AlarmScheduler.TEST_ALARM_ID) {
                    val now = ZonedDateTime.now()
                    val serviceIntent = Intent(appContext, AlarmService::class.java).apply {
                        this.action = AlarmService.ACTION_START_RINGING
                        putExtra(AlarmService.EXTRA_ALARM_ID, AlarmScheduler.TEST_ALARM_ID)
                        putExtra(AlarmService.EXTRA_IS_TEST, true)
                        putExtra(AlarmService.EXTRA_HOUR, now.hour)
                        putExtra(AlarmService.EXTRA_MINUTE, now.minute)
                        putExtra(AlarmService.EXTRA_LABEL, "منبه تجريبي")
                        putExtra(AlarmService.EXTRA_TONE_TYPE, ToneType.CLASSIC_BELL.name)
                        putExtra(AlarmService.EXTRA_VOLUME_PERCENT, 100)
                        putExtra(AlarmService.EXTRA_GRADUAL_VOLUME, false)
                        putExtra(AlarmService.EXTRA_VIBRATE, true)
                        putExtra(AlarmService.EXTRA_SNOOZE_MINUTES, 5)
                        putExtra(AlarmService.EXTRA_SNOOZE_MAX_COUNT, 0)
                        putExtra(AlarmService.EXTRA_SNOOZE_COUNT, 0)
                        putExtra(AlarmService.EXTRA_MATH_CHALLENGE, false)
                    }
                    ContextCompat.startForegroundService(appContext, serviceIntent)
                    return@launch
                }

                val protectedStore = DeviceProtectedAlarmStore(appContext)
                protectedStore.clearSnoozeTarget(alarmId)

                val repository = AlarmRepository(appContext)
                val alarm = repository.getAlarmById(alarmId)
                if (alarm == null) {
                    AlarmRuntimeState.clearRinging()
                    return@launch
                }

                if (!isSnooze) {
                    repository.handlePrimaryTriggerDatabaseUpdate(alarm)
                }

                val serviceIntent = Intent(appContext, AlarmService::class.java).apply {
                    this.action = AlarmService.ACTION_START_RINGING
                    putExtra(AlarmService.EXTRA_ALARM_ID, alarm.id)
                    putExtra(AlarmService.EXTRA_IS_TEST, false)
                    putExtra(AlarmService.EXTRA_HOUR, alarm.hour)
                    putExtra(AlarmService.EXTRA_MINUTE, alarm.minute)
                    putExtra(AlarmService.EXTRA_LABEL, alarm.label)
                    putExtra(AlarmService.EXTRA_TONE_TYPE, alarm.toneType)
                    putExtra(AlarmService.EXTRA_TONE_URI, alarm.toneUri)
                    putExtra(AlarmService.EXTRA_VOLUME_PERCENT, alarm.volumePercent)
                    putExtra(AlarmService.EXTRA_GRADUAL_VOLUME, alarm.gradualVolume)
                    putExtra(AlarmService.EXTRA_VIBRATE, alarm.vibrate)
                    putExtra(AlarmService.EXTRA_SNOOZE_MINUTES, alarm.snoozeMinutes)
                    putExtra(AlarmService.EXTRA_SNOOZE_MAX_COUNT, alarm.snoozeMaxCount)
                    putExtra(AlarmService.EXTRA_SNOOZE_COUNT, alarm.snoozeCount)
                    putExtra(AlarmService.EXTRA_MATH_CHALLENGE, alarm.mathChallenge)
                }
                ContextCompat.startForegroundService(appContext, serviceIntent)
            } catch (_: Exception) {
                AlarmRuntimeState.clearRinging()
            } finally {
                try {
                    if (wakeLock?.isHeld == true) {
                        wakeLock.release()
                    }
                } catch (_: Exception) {
                }
                pendingResult.finish()
            }
        }
    }

    companion object {
        const val ACTION_ALARM_TRIGGER = "com.wakeup.app.action.ALARM_TRIGGER"
        const val ACTION_ALARM_BACKUP_TRIGGER = "com.wakeup.app.action.ALARM_BACKUP_TRIGGER"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_IS_SNOOZE = "extra_is_snooze"
        const val EXTRA_IS_TEST = "extra_is_test"
        const val EXTRA_IS_BACKUP = "extra_is_backup"
        const val EXTRA_EXPECTED_TRIGGER = "extra_expected_trigger"
    }
}
