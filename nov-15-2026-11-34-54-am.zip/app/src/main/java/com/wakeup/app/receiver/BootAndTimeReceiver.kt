package com.wakeup.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.UserManager
import com.wakeup.app.data.local.DeviceProtectedAlarmStore
import com.wakeup.app.data.repository.AlarmRepository
import com.wakeup.app.scheduler.AlarmScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootAndTimeReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action !in SUPPORTED_ACTIONS) return

        val pendingResult = goAsync()
        val appContext = context.applicationContext

        CoroutineScope(Dispatchers.IO).launch {
            try {
                val userManager = appContext.getSystemService(UserManager::class.java)
                val isUserUnlocked = userManager?.isUserUnlocked ?: true

                if (isUserUnlocked) {
                    val repository = AlarmRepository(appContext)
                    repository.rescheduleAllEnabledAlarms()
                } else {
                    val protectedStore = DeviceProtectedAlarmStore(appContext)
                    val scheduler = AlarmScheduler(appContext, protectedStore)
                    scheduler.rescheduleFromProtectedCache()
                }
            } catch (_: Exception) {
                // Ignore if system is mid-boot
            } finally {
                pendingResult.finish()
            }
        }
    }

    companion object {
        private val SUPPORTED_ACTIONS = setOf(
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_LOCKED_BOOT_COMPLETED,
            "android.intent.action.QUICKBOOT_POWERON",
            "com.htc.intent.action.QUICKBOOT_POWERON",
            Intent.ACTION_MY_PACKAGE_REPLACED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_DATE_CHANGED,
            Intent.ACTION_USER_UNLOCKED
        )
    }
}
