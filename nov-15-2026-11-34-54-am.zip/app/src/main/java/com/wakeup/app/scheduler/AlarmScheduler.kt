package com.wakeup.app.scheduler

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.wakeup.app.MainActivity
import com.wakeup.app.data.local.CachedAlarmSchedule
import com.wakeup.app.data.local.DeviceProtectedAlarmStore
import com.wakeup.app.data.model.Alarm
import com.wakeup.app.receiver.AlarmReceiver
import com.wakeup.app.util.AlarmTimeCalculator

class AlarmScheduler(
    private val context: Context,
    private val protectedStore: DeviceProtectedAlarmStore = DeviceProtectedAlarmStore(context)
) {
    private val alarmManager = context.getSystemService(AlarmManager::class.java)

    fun scheduleAlarm(alarm: Alarm): Long? {
        if (!alarm.enabled) {
            cancelAlarm(alarm.id)
            return null
        }
        val triggerAtMillis = AlarmTimeCalculator.computeNextTriggerMillis(
            hour = alarm.hour,
            minute = alarm.minute,
            daysMask = alarm.daysMask
        )
        scheduleExactPair(
            alarmId = alarm.id,
            triggerAtMillis = triggerAtMillis,
            isSnooze = false,
            isTest = false
        )
        return triggerAtMillis
    }

    fun scheduleSnooze(alarm: Alarm): Long {
        val triggerAtMillis = System.currentTimeMillis() + alarm.snoozeMinutes.coerceAtLeast(1) * 60_000L
        protectedStore.setSnoozeTarget(alarm.id, triggerAtMillis)
        scheduleExactPair(
            alarmId = alarm.id,
            triggerAtMillis = triggerAtMillis,
            isSnooze = true,
            isTest = false
        )
        return triggerAtMillis
    }

    fun scheduleTestAlarm(): Long {
        val triggerAtMillis = System.currentTimeMillis() + 10_000L
        scheduleExactPair(
            alarmId = TEST_ALARM_ID,
            triggerAtMillis = triggerAtMillis,
            isSnooze = false,
            isTest = true
        )
        return triggerAtMillis
    }

    fun cancelAlarm(alarmId: Long) {
        protectedStore.clearSnoozeTarget(alarmId)
        val manager = alarmManager ?: return
        listOf(
            buildTriggerPendingIntent(alarmId, 0L, isSnooze = false, isTest = false, isBackup = false),
            buildTriggerPendingIntent(alarmId, 0L, isSnooze = false, isTest = false, isBackup = true),
            buildTriggerPendingIntent(alarmId, 0L, isSnooze = true, isTest = false, isBackup = false),
            buildTriggerPendingIntent(alarmId, 0L, isSnooze = true, isTest = false, isBackup = true)
        ).forEach { pendingIntent ->
            manager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }

    fun rescheduleAll(enabledAlarms: List<Alarm>) {
        val snapshots = enabledAlarms.map {
            CachedAlarmSchedule(
                id = it.id,
                hour = it.hour,
                minute = it.minute,
                daysMask = it.daysMask
            )
        }
        protectedStore.saveEnabledAlarmsSnapshot(snapshots)

        enabledAlarms.forEach { alarm ->
            scheduleAlarm(alarm)
        }

        rescheduleStoredSnoozes()
    }

    fun rescheduleFromProtectedCache() {
        val snapshots = protectedStore.getEnabledAlarmsSnapshot()
        snapshots.forEach { item ->
            val triggerAtMillis = AlarmTimeCalculator.computeNextTriggerMillis(
                hour = item.hour,
                minute = item.minute,
                daysMask = item.daysMask
            )
            scheduleExactPair(
                alarmId = item.id,
                triggerAtMillis = triggerAtMillis,
                isSnooze = false,
                isTest = false
            )
        }
        rescheduleStoredSnoozes()
    }

    private fun rescheduleStoredSnoozes() {
        val now = System.currentTimeMillis()
        protectedStore.getAllSnoozeTargets().forEach { (alarmId, triggerAtMillis) ->
            if (triggerAtMillis > now - 30_000L) {
                val safeTrigger = triggerAtMillis.coerceAtLeast(now + 1_000L)
                scheduleExactPair(
                    alarmId = alarmId,
                    triggerAtMillis = safeTrigger,
                    isSnooze = true,
                    isTest = false
                )
            } else {
                protectedStore.clearSnoozeTarget(alarmId)
            }
        }
    }

    private fun scheduleExactPair(
        alarmId: Long,
        triggerAtMillis: Long,
        isSnooze: Boolean,
        isTest: Boolean
    ) {
        val manager = alarmManager ?: return
        val canExact = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            manager.canScheduleExactAlarms()
        } else {
            true
        }

        val showIntent = PendingIntent.getActivity(
            context,
            0,
            Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            },
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val primaryPendingIntent = buildTriggerPendingIntent(
            alarmId = alarmId,
            triggerAtMillis = triggerAtMillis,
            isSnooze = isSnooze,
            isTest = isTest,
            isBackup = false
        )

        val backupPendingIntent = buildTriggerPendingIntent(
            alarmId = alarmId,
            triggerAtMillis = triggerAtMillis,
            isSnooze = isSnooze,
            isTest = isTest,
            isBackup = true
        )

        try {
            if (canExact) {
                val clockInfo = AlarmManager.AlarmClockInfo(triggerAtMillis, showIntent)
                manager.setAlarmClock(clockInfo, primaryPendingIntent)
                manager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    backupPendingIntent
                )
            } else {
                // Fallback when SCHEDULE_EXACT_ALARM is not granted yet
                manager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    primaryPendingIntent
                )
            }
        } catch (_: SecurityException) {
            try {
                manager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    primaryPendingIntent
                )
            } catch (_: Exception) {
            }
        }
    }

    private fun buildTriggerPendingIntent(
        alarmId: Long,
        triggerAtMillis: Long,
        isSnooze: Boolean,
        isTest: Boolean,
        isBackup: Boolean
    ): PendingIntent {
        val action = if (isBackup) {
            AlarmReceiver.ACTION_ALARM_BACKUP_TRIGGER
        } else {
            AlarmReceiver.ACTION_ALARM_TRIGGER
        }

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            this.action = action
            putExtra(AlarmReceiver.EXTRA_ALARM_ID, alarmId)
            putExtra(AlarmReceiver.EXTRA_IS_SNOOZE, isSnooze)
            putExtra(AlarmReceiver.EXTRA_IS_TEST, isTest)
            putExtra(AlarmReceiver.EXTRA_IS_BACKUP, isBackup)
            putExtra(AlarmReceiver.EXTRA_EXPECTED_TRIGGER, triggerAtMillis)
        }

        val requestCode = computeRequestCode(alarmId, isSnooze, isTest, isBackup)
        return PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    private fun computeRequestCode(
        alarmId: Long,
        isSnooze: Boolean,
        isTest: Boolean,
        isBackup: Boolean
    ): Int {
        if (isTest) {
            return if (isBackup) -9992 else -9991
        }
        val base = ((alarmId and 0x0FFFFFFFL).toInt()) * 8
        val offset = when {
            !isSnooze && !isBackup -> 1
            !isSnooze && isBackup -> 2
            isSnooze && !isBackup -> 3
            else -> 4
        }
        return base + offset
    }

    companion object {
        const val TEST_ALARM_ID = -999L
    }
}
