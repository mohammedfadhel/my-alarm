package com.wakeup.app.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.wakeup.app.MainActivity
import com.wakeup.app.R
import com.wakeup.app.ui.ringing.RingingActivity
import com.wakeup.app.util.AlarmTimeCalculator

object AlarmNotificationHelper {

    const val CHANNEL_RINGING = "monabihi_alarm_ringing_channel"
    const val CHANNEL_MISSED = "monabihi_alarm_missed_channel"

    const val NOTIFICATION_ID_RINGING = 1001
    private const val NOTIFICATION_ID_MISSED_BASE = 2000

    fun ensureChannels(context: Context) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val ringingChannel = NotificationChannel(
            CHANNEL_RINGING,
            "تنبيهات المنبه",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "إشعارات رنين المنبه بملء الشاشة"
            setSound(null, null)
            enableVibration(false)
            setBypassDnd(true)
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        val missedChannel = NotificationChannel(
            CHANNEL_MISSED,
            "منبهات فائتة",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "تنبيه عند فوات منبه بعد رنينه لمدة 10 دقائق"
            lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        }

        manager.createNotificationChannel(ringingChannel)
        manager.createNotificationChannel(missedChannel)
    }

    fun buildRingingNotification(
        context: Context,
        state: ActiveAlarmState
    ): Notification {
        ensureChannels(context)

        val fullScreenIntent = Intent(context, RingingActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(RingingActivity.EXTRA_OPEN_CHALLENGE, state.openChallengeImmediately)
        }
        val fullScreenPendingIntent = PendingIntent.getActivity(
            context,
            101,
            fullScreenIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(context, AlarmService::class.java).apply {
            action = AlarmService.ACTION_STOP_FROM_NOTIFICATION
        }
        val stopPendingIntent = PendingIntent.getService(
            context,
            102,
            stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val (timeText, period) = AlarmTimeCalculator.formatTimeArabic(
            context,
            state.hour,
            state.minute
        )
        val formattedTime = if (period != null) "$timeText $period" else timeText
        val title = if (state.isTest) {
            "منبه تجريبي - $formattedTime"
        } else if (state.label.isNotBlank()) {
            "${state.label} • $formattedTime"
        } else {
            "منبهي • $formattedTime"
        }

        val contentText = if (state.mathChallenge) {
            "اضغط إيقاف لحل تحدي الاستيقاظ"
        } else {
            "المنبه يرن الآن"
        }

        val builder = NotificationCompat.Builder(context, CHANNEL_RINGING)
            .setSmallIcon(R.drawable.ic_alarm_notification)
            .setContentTitle(title)
            .setContentText(contentText)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setOngoing(true)
            .setAutoCancel(false)
            .setContentIntent(fullScreenPendingIntent)
            .setFullScreenIntent(fullScreenPendingIntent, true)
            .addAction(
                R.drawable.ic_alarm_notification,
                "إيقاف",
                stopPendingIntent
            )

        if (state.canSnooze) {
            val snoozeIntent = Intent(context, AlarmService::class.java).apply {
                action = AlarmService.ACTION_SNOOZE_FROM_NOTIFICATION
            }
            val snoozePendingIntent = PendingIntent.getService(
                context,
                103,
                snoozeIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            builder.addAction(
                R.drawable.ic_alarm_notification,
                "غفوة ${state.snoozeMinutes} د",
                snoozePendingIntent
            )
        }

        return builder.build()
    }

    fun showMissedAlarmNotification(
        context: Context,
        alarmId: Long,
        hour: Int,
        minute: Int,
        label: String
    ) {
        ensureChannels(context)
        val manager = context.getSystemService(NotificationManager::class.java) ?: return

        val (timeText, period) = AlarmTimeCalculator.formatTimeArabic(context, hour, minute)
        val formattedTime = if (period != null) "$timeText $period" else timeText

        val body = if (label.isNotBlank()) {
            "فاتك منبه \"$label\" الساعة $formattedTime"
        } else {
            "فاتك منبه الساعة $formattedTime"
        }

        val openAppIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            context,
            NOTIFICATION_ID_MISSED_BASE + (alarmId.toInt() and 0xFFFF),
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_MISSED)
            .setSmallIcon(R.drawable.ic_alarm_notification)
            .setContentTitle("فاتك منبه")
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setAutoCancel(false)
            .setContentIntent(openPendingIntent)
            .build()

        val notifId = NOTIFICATION_ID_MISSED_BASE + ((alarmId and 0x7FFFL).toInt())
        manager.notify(notifId, notification)
    }
}
