package com.wakeup.app.service

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.abs

data class ActiveAlarmState(
    val alarmId: Long,
    val hour: Int,
    val minute: Int,
    val label: String,
    val snoozeMinutes: Int,
    val snoozeMaxCount: Int,
    val snoozeCount: Int,
    val mathChallenge: Boolean,
    val isTest: Boolean,
    val openChallengeImmediately: Boolean = false
) {
    val canSnooze: Boolean
        get() = !isTest && (snoozeMaxCount == -1 || snoozeCount < snoozeMaxCount)

    val remainingSnoozes: Int?
        get() = if (snoozeMaxCount == -1) null else (snoozeMaxCount - snoozeCount).coerceAtLeast(0)
}

object AlarmRuntimeState {
    private val ringingFlag = AtomicBoolean(false)
    private val guardLock = Any()

    private var lastHandledAlarmId: Long = Long.MIN_VALUE
    private var lastHandledTriggerMillis: Long = 0L

    private val _activeAlarm = MutableStateFlow<ActiveAlarmState?>(null)
    val activeAlarm: StateFlow<ActiveAlarmState?> = _activeAlarm.asStateFlow()

    fun isCurrentlyRinging(): Boolean = ringingFlag.get()

    /**
     * Atomically claims a trigger event so primary setAlarmClock and backup
     * setExactAndAllowWhileIdle never launch duplicate ringing sessions.
     */
    fun tryClaimTrigger(
        alarmId: Long,
        expectedTriggerMillis: Long,
        isBackup: Boolean
    ): Boolean {
        synchronized(guardLock) {
            if (ringingFlag.get()) {
                return false
            }
            val now = System.currentTimeMillis()
            val sameTriggerWindow =
                lastHandledAlarmId == alarmId &&
                    expectedTriggerMillis > 0L &&
                    abs(lastHandledTriggerMillis - expectedTriggerMillis) < 90_000L &&
                    (now - lastHandledTriggerMillis) < 90_000L

            if (isBackup && sameTriggerWindow) {
                return false
            }
            if (sameTriggerWindow) {
                return false
            }

            lastHandledAlarmId = alarmId
            lastHandledTriggerMillis = if (expectedTriggerMillis > 0L) expectedTriggerMillis else now
            ringingFlag.set(true)
            return true
        }
    }

    fun setActiveAlarm(state: ActiveAlarmState) {
        ringingFlag.set(true)
        _activeAlarm.value = state
    }

    fun requestOpenMathChallenge() {
        val current = _activeAlarm.value ?: return
        _activeAlarm.value = current.copy(openChallengeImmediately = true)
    }

    fun clearRinging() {
        synchronized(guardLock) {
            ringingFlag.set(false)
            _activeAlarm.value = null
        }
    }
}
