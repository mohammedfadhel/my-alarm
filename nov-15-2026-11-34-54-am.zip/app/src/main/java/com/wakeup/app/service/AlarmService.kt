package com.wakeup.app.service

import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import com.wakeup.app.audio.AlarmSoundController
import com.wakeup.app.data.local.AlarmDatabase
import com.wakeup.app.data.model.Alarm
import com.wakeup.app.data.model.ToneType
import com.wakeup.app.data.repository.AlarmRepository
import com.wakeup.app.scheduler.AlarmScheduler
import com.wakeup.app.ui.ringing.RingingActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AlarmService : Service() {

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var soundController: AlarmSoundController
    private var wakeLock: PowerManager.WakeLock? = null
    private var timeoutJob: Job? = null
    private var currentAlarmId: Long = Long.MIN_VALUE
    private var currentAlarmSnapshot: Alarm? = null
    private var currentIsTest: Boolean = false

    override fun onCreate() {
        super.onCreate()
        soundController = AlarmSoundController(this)
        val powerManager = getSystemService(PowerManager::class.java)
        wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "Monabihi:AlarmServiceWakeLock"
        )?.apply {
            setReferenceCounted(false)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_FROM_UI -> {
                handleStopFromUi()
                return START_NOT_STICKY
            }

            ACTION_STOP_FROM_NOTIFICATION -> {
                val active = AlarmRuntimeState.activeAlarm.value
                if (active != null && active.mathChallenge) {
                    AlarmRuntimeState.requestOpenMathChallenge()
                    launchRingingActivity(openChallengeImmediately = true)
                } else {
                    handleStopFromUi()
                }
                return START_NOT_STICKY
            }

            ACTION_SNOOZE_FROM_UI,
            ACTION_SNOOZE_FROM_NOTIFICATION -> {
                handleSnooze()
                return START_NOT_STICKY
            }
        }

        val alarmId = intent?.getLongExtra(EXTRA_ALARM_ID, Long.MIN_VALUE) ?: Long.MIN_VALUE
        val isTest = intent?.getBooleanExtra(EXTRA_IS_TEST, false) ?: false
        val hour = intent?.getIntExtra(EXTRA_HOUR, 7) ?: 7
        val minute = intent?.getIntExtra(EXTRA_MINUTE, 0) ?: 0
        val label = intent?.getStringExtra(EXTRA_LABEL) ?: ""
        val toneTypeName = intent?.getStringExtra(EXTRA_TONE_TYPE) ?: ToneType.CLASSIC_BELL.name
        val toneUri = intent?.getStringExtra(EXTRA_TONE_URI)
        val volumePercent = intent?.getIntExtra(EXTRA_VOLUME_PERCENT, 100) ?: 100
        val gradualVolume = intent?.getBooleanExtra(EXTRA_GRADUAL_VOLUME, false) ?: false
        val vibrate = intent?.getBooleanExtra(EXTRA_VIBRATE, true) ?: true
        val snoozeMinutes = intent?.getIntExtra(EXTRA_SNOOZE_MINUTES, 5) ?: 5
        val snoozeMaxCount = intent?.getIntExtra(EXTRA_SNOOZE_MAX_COUNT, 3) ?: 3
        val snoozeCount = intent?.getIntExtra(EXTRA_SNOOZE_COUNT, 0) ?: 0
        val mathChallenge = intent?.getBooleanExtra(EXTRA_MATH_CHALLENGE, false) ?: false

        val alarm = Alarm(
            id = alarmId,
            hour = hour,
            minute = minute,
            label = label,
            daysMask = 0,
            enabled = true,
            toneType = toneTypeName,
            toneUri = toneUri,
            volumePercent = volumePercent,
            gradualVolume = gradualVolume,
            vibrate = vibrate,
            snoozeMinutes = snoozeMinutes,
            snoozeMaxCount = snoozeMaxCount,
            mathChallenge = mathChallenge,
            snoozeCount = snoozeCount
        )

        currentAlarmId = alarmId
        currentAlarmSnapshot = alarm
        currentIsTest = isTest

        val activeState = ActiveAlarmState(
            alarmId = alarmId,
            hour = hour,
            minute = minute,
            label = label,
            snoozeMinutes = snoozeMinutes,
            snoozeMaxCount = snoozeMaxCount,
            snoozeCount = snoozeCount,
            mathChallenge = mathChallenge,
            isTest = isTest
        )
        AlarmRuntimeState.setActiveAlarm(activeState)

        val notification = AlarmNotificationHelper.buildRingingNotification(this, activeState)
        startForeground(AlarmNotificationHelper.NOTIFICATION_ID_RINGING, notification)

        acquireServiceWakeLock()
        startRingingMedia(alarm)
        launchRingingActivity(openChallengeImmediately = false)
        startTenMinuteMissedTimeout(alarm, isTest)

        return START_NOT_STICKY
    }

    private fun startRingingMedia(alarm: Alarm) {
        soundController.start(
            scope = serviceScope,
            toneType = ToneType.fromName(alarm.toneType),
            toneUri = alarm.toneUri,
            volumePercent = alarm.volumePercent,
            gradualVolume = alarm.gradualVolume
        )
        if (alarm.vibrate) {
            startVibration()
        } else {
            stopVibration()
        }
    }

    private fun launchRingingActivity(openChallengeImmediately: Boolean) {
        val activityIntent = Intent(this, RingingActivity::class.java).apply {
            addFlags(
                Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_CLEAR_TOP or
                    Intent.FLAG_ACTIVITY_NO_USER_ACTION
            )
            putExtra(RingingActivity.EXTRA_OPEN_CHALLENGE, openChallengeImmediately)
        }
        try {
            startActivity(activityIntent)
        } catch (_: Exception) {
            // Full-screen intent notification remains active as fallback
        }
    }

    private fun startTenMinuteMissedTimeout(alarm: Alarm, isTest: Boolean) {
        timeoutJob?.cancel()
        timeoutJob = serviceScope.launch {
            delay(MAX_RING_DURATION_MILLIS)
            if (!isTest) {
                AlarmNotificationHelper.showMissedAlarmNotification(
                    context = this@AlarmService,
                    alarmId = alarm.id,
                    hour = alarm.hour,
                    minute = alarm.minute,
                    label = alarm.label
                )
                serviceScope.launch(Dispatchers.IO) {
                    val repo = AlarmRepository(applicationContext)
                    repo.resetSnoozeCount(alarm.id)
                }
            }
            shutdownService()
        }
    }

    private fun handleStopFromUi() {
        val alarmId = currentAlarmId
        val isTest = currentIsTest
        if (!isTest && alarmId != Long.MIN_VALUE && alarmId != AlarmScheduler.TEST_ALARM_ID) {
            CoroutineScope(Dispatchers.IO).launch {
                val repo = AlarmRepository(applicationContext)
                repo.resetSnoozeCount(alarmId)
            }
        }
        shutdownService()
    }

    private fun handleSnooze() {
        val active = AlarmRuntimeState.activeAlarm.value
        val alarmId = currentAlarmId
        if (active != null && !active.canSnooze) {
            return
        }
        if (!currentIsTest && alarmId != Long.MIN_VALUE && alarmId != AlarmScheduler.TEST_ALARM_ID) {
            val snapshot = currentAlarmSnapshot
            CoroutineScope(Dispatchers.IO).launch {
                val repo = AlarmRepository(applicationContext)
                val updated = repo.incrementSnoozeCountAndSchedule(alarmId)
                if (updated == null && snapshot != null) {
                    repo.scheduler.scheduleSnooze(snapshot)
                }
            }
        }
        shutdownService()
    }

    private fun shutdownService() {
        timeoutJob?.cancel()
        timeoutJob = null
        soundController.stop()
        stopVibration()
        AlarmRuntimeState.clearRinging()
        releaseServiceWakeLock()
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun startVibration() {
        val vibrator = getVibrator() ?: return
        if (!vibrator.hasVibrator()) return
        val pattern = longArrayOf(0L, 600L, 300L, 600L, 400L)
        val effect = VibrationEffect.createWaveform(pattern, 0)
        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_ALARM)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        @Suppress("DEPRECATION")
        vibrator.vibrate(effect, attributes)
    }

    private fun stopVibration() {
        getVibrator()?.cancel()
    }

    private fun getVibrator(): Vibrator? {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            getSystemService(VibratorManager::class.java)?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private fun acquireServiceWakeLock() {
        try {
            val lock = wakeLock ?: return
            if (!lock.isHeld) {
                lock.acquire(11 * 60 * 1000L)
            }
        } catch (_: Exception) {
        }
    }

    private fun releaseServiceWakeLock() {
        try {
            val lock = wakeLock ?: return
            if (lock.isHeld) {
                lock.release()
            }
        } catch (_: Exception) {
        }
    }

    override fun onDestroy() {
        timeoutJob?.cancel()
        soundController.stop()
        stopVibration()
        AlarmRuntimeState.clearRinging()
        releaseServiceWakeLock()
        serviceScope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        private const val MAX_RING_DURATION_MILLIS = 10 * 60 * 1000L

        const val ACTION_START_RINGING = "com.wakeup.app.action.START_RINGING"
        const val ACTION_STOP_FROM_UI = "com.wakeup.app.action.STOP_FROM_UI"
        const val ACTION_STOP_FROM_NOTIFICATION = "com.wakeup.app.action.STOP_FROM_NOTIFICATION"
        const val ACTION_SNOOZE_FROM_UI = "com.wakeup.app.action.SNOOZE_FROM_UI"
        const val ACTION_SNOOZE_FROM_NOTIFICATION = "com.wakeup.app.action.SNOOZE_FROM_NOTIFICATION"

        const val EXTRA_ALARM_ID = "extra_alarm_id"
        const val EXTRA_IS_TEST = "extra_is_test"
        const val EXTRA_HOUR = "extra_hour"
        const val EXTRA_MINUTE = "extra_minute"
        const val EXTRA_LABEL = "extra_label"
        const val EXTRA_TONE_TYPE = "extra_tone_type"
        const val EXTRA_TONE_URI = "extra_tone_uri"
        const val EXTRA_VOLUME_PERCENT = "extra_volume_percent"
        const val EXTRA_GRADUAL_VOLUME = "extra_gradual_volume"
        const val EXTRA_VIBRATE = "extra_vibrate"
        const val EXTRA_SNOOZE_MINUTES = "extra_snooze_minutes"
        const val EXTRA_SNOOZE_MAX_COUNT = "extra_snooze_max_count"
        const val EXTRA_SNOOZE_COUNT = "extra_snooze_count"
        const val EXTRA_MATH_CHALLENGE = "extra_math_challenge"

        fun stopAlarm(context: Context) {
            val intent = Intent(context, AlarmService::class.java).apply {
                action = ACTION_STOP_FROM_UI
            }
            context.startService(intent)
        }

        fun snoozeAlarm(context: Context) {
            val intent = Intent(context, AlarmService::class.java).apply {
                action = ACTION_SNOOZE_FROM_UI
            }
            context.startService(intent)
        }
    }
}
