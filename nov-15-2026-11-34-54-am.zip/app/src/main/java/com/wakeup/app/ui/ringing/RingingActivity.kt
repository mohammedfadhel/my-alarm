package com.wakeup.app.ui.ringing

import android.app.KeyguardManager
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Snooze
import androidx.compose.material.icons.filled.StopCircle
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wakeup.app.service.ActiveAlarmState
import com.wakeup.app.service.AlarmRuntimeState
import com.wakeup.app.service.AlarmService
import com.wakeup.app.ui.theme.MonabihiTheme
import com.wakeup.app.util.AlarmTimeCalculator
import kotlinx.coroutines.delay
import java.time.ZonedDateTime
import kotlin.random.Random

class RingingActivity : ComponentActivity() {

    private var openChallengeState = mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        configureLockScreenFlags()
        enableEdgeToEdge()

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // Prevent accidentally dismissing the ringing screen with Back button
            }
        })

        openChallengeState.value = intent?.getBooleanExtra(EXTRA_OPEN_CHALLENGE, false) ?: false

        setContent {
            MonabihiTheme(darkTheme = true) {
                val activeAlarm by AlarmRuntimeState.activeAlarm.collectAsStateWithLifecycle()

                LaunchedEffect(activeAlarm) {
                    if (activeAlarm == null) {
                        finish()
                    } else if (activeAlarm?.openChallengeImmediately == true) {
                        openChallengeState.value = true
                    }
                }

                val current = activeAlarm
                if (current != null) {
                    RingingScreenContent(
                        alarmState = current,
                        forceShowChallenge = openChallengeState.value,
                        onOpenChallenge = { openChallengeState.value = true },
                        onStopConfirmed = {
                            AlarmService.stopAlarm(this)
                            finish()
                        },
                        onSnooze = {
                            AlarmService.snoozeAlarm(this)
                            finish()
                        }
                    )
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        configureLockScreenFlags()
        if (intent.getBooleanExtra(EXTRA_OPEN_CHALLENGE, false)) {
            openChallengeState.value = true
        }
    }

    private fun configureLockScreenFlags() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O_MR1) {
            setShowWhenLocked(true)
            setTurnScreenOn(true)
        } else {
            @Suppress("DEPRECATION")
            window.addFlags(
                WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
            )
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val keyguardManager = getSystemService(KeyguardManager::class.java)
        keyguardManager?.requestDismissKeyguard(this, null)
    }

    companion object {
        const val EXTRA_OPEN_CHALLENGE = "extra_open_challenge"
    }
}

private data class MathProblem(
    val expression: String,
    val answer: Int
)

private fun generateMathProblems(count: Int = 3): List<MathProblem> {
    return List(count) {
        val pattern = Random.nextInt(3)
        when (pattern) {
            0 -> {
                val a = Random.nextInt(5, 20)
                val b = Random.nextInt(2, 10)
                val c = Random.nextInt(2, 6)
                MathProblem("$a + $b × $c", a + (b * c))
            }
            1 -> {
                val a = Random.nextInt(3, 10)
                val b = Random.nextInt(3, 9)
                val c = Random.nextInt(1, 10)
                MathProblem("$a × $b + $c", (a * b) + c)
            }
            else -> {
                val a = Random.nextInt(4, 11)
                val b = Random.nextInt(3, 9)
                val c = Random.nextInt(1, (a * b) - 1)
                MathProblem("$a × $b - $c", (a * b) - c)
            }
        }
    }
}

@Composable
private fun RingingScreenContent(
    alarmState: ActiveAlarmState,
    forceShowChallenge: Boolean,
    onOpenChallenge: () -> Unit,
    onStopConfirmed: () -> Unit,
    onSnooze: () -> Unit
) {
    val context = LocalContext.current
    var currentTime by remember { mutableStateOf(ZonedDateTime.now()) }
    var showingMathChallenge by remember(alarmState.alarmId, forceShowChallenge) {
        mutableStateOf(forceShowChallenge && alarmState.mathChallenge)
    }

    LaunchedEffect(Unit) {
        while (true) {
            currentTime = ZonedDateTime.now()
            delay(1_000L)
        }
    }

    val (clockText, period) = AlarmTimeCalculator.formatTimeArabic(
        context,
        currentTime.hour,
        currentTime.minute
    )

    val snoozeRemainingText = when {
        alarmState.isTest -> "هذا منبه تجريبي"
        !alarmState.canSnooze -> "انتهت مرات الغفوة المتاحة"
        alarmState.remainingSnoozes == null -> "غفوات متاحة: بلا حدود"
        else -> "الغفوات المتبقية: ${alarmState.remainingSnoozes}"
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0A111C),
                        Color(0xFF162235),
                        Color(0xFF0A111C)
                    )
                )
            )
            .padding(horizontal = 24.dp, vertical = 40.dp)
    ) {
        if (showingMathChallenge) {
            MathChallengePanel(
                alarmState = alarmState,
                snoozeRemainingText = snoozeRemainingText,
                onSolvedAll = onStopConfirmed,
                onSnooze = onSnooze
            )
        } else {
            Column(
                modifier = Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.padding(top = 24.dp)
                ) {
                    Icon(
                        imageVector = Icons.Filled.Alarm,
                        contentDescription = null,
                        tint = Color(0xFFFFB74D),
                        modifier = Modifier.size(52.dp)
                    )
                    Spacer(modifier = Modifier.height(14.dp))
                    Row(
                        verticalAlignment = Alignment.Bottom,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Text(
                            text = clockText,
                            fontSize = 72.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            lineHeight = 76.sp
                        )
                        if (period != null) {
                            Text(
                                text = period,
                                fontSize = 26.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFFFFB74D),
                                modifier = Modifier.padding(bottom = 12.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = if (alarmState.label.isNotBlank()) alarmState.label else "منبهي",
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = snoozeRemainingText,
                        style = MaterialTheme.typography.bodyLarge,
                        color = Color(0xFFB8C4D0)
                    )
                }

                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    if (alarmState.canSnooze) {
                        val snoozeLabel = when (alarmState.snoozeMinutes) {
                            1 -> "غفوة دقيقة واحدة"
                            else -> "غفوة ${alarmState.snoozeMinutes} دقائق"
                        }
                        FilledTonalButton(
                            onClick = onSnooze,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(68.dp),
                            shape = RoundedCornerShape(20.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF253549),
                                contentColor = Color.White
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Snooze,
                                contentDescription = null,
                                modifier = Modifier.size(26.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = snoozeLabel,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = {
                            if (alarmState.mathChallenge) {
                                showingMathChallenge = true
                                onOpenChallenge()
                            } else {
                                onStopConfirmed()
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(74.dp),
                        shape = RoundedCornerShape(20.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFFDC2626),
                            contentColor = Color.White
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Filled.StopCircle,
                            contentDescription = null,
                            modifier = Modifier.size(28.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "إيقاف",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun MathChallengePanel(
    alarmState: ActiveAlarmState,
    snoozeRemainingText: String,
    onSolvedAll: () -> Unit,
    onSnooze: () -> Unit
) {
    val problems = remember(alarmState.alarmId) { generateMathProblems(3) }
    var currentIndex by remember { mutableIntStateOf(0) }
    var userInput by remember { mutableStateOf("") }
    var wrongAttempt by remember { mutableStateOf(false) }

    val currentProblem = problems[currentIndex]

    Column(
        modifier = Modifier.fillMaxSize(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "تحدي الإيقاف",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFFFFB74D)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "المسألة ${currentIndex + 1} من ${problems.size}",
                style = MaterialTheme.typography.titleMedium,
                color = Color(0xFFB8C4D0)
            )

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1F2D3E))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 22.dp, horizontal = 16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Text(
                            text = "${currentProblem.expression} = ?",
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = if (userInput.isEmpty()) "___" else userInput,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFFFB74D)
                    )
                    if (wrongAttempt) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "إجابة غير صحيحة، حاول مرة أخرى",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color(0xFFFF6B6B),
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Numeric Keypad
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val rows = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9")
            )
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    rows.forEach { rowDigits ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            rowDigits.forEach { digit ->
                                FilledTonalButton(
                                    onClick = {
                                        wrongAttempt = false
                                        if (userInput.length < 5) {
                                            userInput += digit
                                        }
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(56.dp),
                                    shape = RoundedCornerShape(14.dp),
                                    colors = ButtonDefaults.filledTonalButtonColors(
                                        containerColor = Color(0xFF253549),
                                        contentColor = Color.White
                                    )
                                ) {
                                    Text(digit, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                wrongAttempt = false
                                if (userInput.isNotEmpty()) {
                                    userInput = userInput.dropLast(1)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Backspace,
                                contentDescription = "مسح",
                                tint = Color.White
                            )
                        }

                        FilledTonalButton(
                            onClick = {
                                wrongAttempt = false
                                if (userInput.length < 5) {
                                    userInput += "0"
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.filledTonalButtonColors(
                                containerColor = Color(0xFF253549),
                                contentColor = Color.White
                            )
                        ) {
                            Text("0", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                val parsed = userInput.toIntOrNull()
                                if (parsed == currentProblem.answer) {
                                    wrongAttempt = false
                                    userInput = ""
                                    if (currentIndex + 1 >= problems.size) {
                                        onSolvedAll()
                                    } else {
                                        currentIndex += 1
                                    }
                                } else {
                                    wrongAttempt = true
                                    userInput = ""
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .height(56.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF16A34A),
                                contentColor = Color.White
                            )
                        ) {
                            Text("تأكيد", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (alarmState.canSnooze) {
                val snoozeLabel = when (alarmState.snoozeMinutes) {
                    1 -> "غفوة دقيقة واحدة ($snoozeRemainingText)"
                    else -> "غفوة ${alarmState.snoozeMinutes} دقائق"
                }
                FilledTonalButton(
                    onClick = onSnooze,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = Color(0xFF334155),
                        contentColor = Color.White
                    )
                ) {
                    Icon(imageVector = Icons.Filled.Snooze, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(snoozeLabel, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
