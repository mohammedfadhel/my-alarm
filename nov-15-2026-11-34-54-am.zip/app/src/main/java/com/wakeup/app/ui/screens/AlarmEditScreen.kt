package com.wakeup.app.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import android.text.format.DateFormat
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AudioFile
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TimePicker
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberTimePickerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wakeup.app.audio.TonePreviewPlayer
import com.wakeup.app.data.model.Alarm
import com.wakeup.app.data.model.ToneType
import com.wakeup.app.ui.viewmodel.AlarmViewModel
import com.wakeup.app.util.WeekdayMask
import kotlin.math.roundToInt

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AlarmEditScreen(
    alarmId: Long,
    viewModel: AlarmViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val isEditing = alarmId > 0L
    val is24Hour = remember(context) { DateFormat.is24HourFormat(context) }

    var loaded by remember { mutableStateOf(!isEditing) }
    var existingAlarm by remember { mutableStateOf<Alarm?>(null) }

    var initialHour by remember { mutableIntStateOf(6) }
    var initialMinute by remember { mutableIntStateOf(30) }
    var label by remember { mutableStateOf("") }
    var daysMask by remember { mutableIntStateOf(0) }
    var selectedTone by remember { mutableStateOf(ToneType.CLASSIC_BELL) }
    var customToneUri by remember { mutableStateOf<String?>(null) }
    var volumePercent by remember { mutableIntStateOf(100) }
    var gradualVolume by remember { mutableStateOf(false) }
    var vibrate by remember { mutableStateOf(true) }
    var snoozeMinutes by remember { mutableIntStateOf(5) }
    var snoozeMaxCount by remember { mutableIntStateOf(3) }
    var mathChallenge by remember { mutableStateOf(false) }
    var showDeleteConfirm by remember { mutableStateOf(false) }

    LaunchedEffect(alarmId) {
        if (isEditing) {
            val found = viewModel.getAlarmById(alarmId)
            if (found != null) {
                existingAlarm = found
                initialHour = found.hour
                initialMinute = found.minute
                label = found.label
                daysMask = found.daysMask
                selectedTone = ToneType.fromName(found.toneType)
                customToneUri = found.toneUri
                volumePercent = found.volumePercent
                gradualVolume = found.gradualVolume
                vibrate = found.vibrate
                snoozeMinutes = found.snoozeMinutes
                snoozeMaxCount = found.snoozeMaxCount
                mathChallenge = found.mathChallenge
            }
            loaded = true
        }
    }

    val previewPlayer = remember(context) { TonePreviewPlayer(context) }
    val playingTone by previewPlayer.playingTone.collectAsStateWithLifecycle()

    DisposableEffect(Unit) {
        onDispose {
            previewPlayer.stop()
        }
    }

    val openAudioLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                context.contentResolver.takePersistableUriPermission(
                    uri,
                    Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (_: SecurityException) {
            }
            customToneUri = uri.toString()
            selectedTone = ToneType.CUSTOM_URI
        }
    }

    if (!loaded) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("تعديل المنبه") },
                    navigationIcon = {
                        IconButton(onClick = onNavigateBack) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "رجوع"
                            )
                        }
                    }
                )
            }
        ) { padding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                verticalArrangement = Arrangement.Center,
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("جاري التحميل...")
            }
        }
        return
    }

    val timePickerState = rememberTimePickerState(
        initialHour = initialHour,
        initialMinute = initialMinute,
        is24Hour = is24Hour
    )

    val customFileName = remember(customToneUri) {
        customToneUri?.let { resolveDisplayName(context, it) }
    }

    val saveCurrentAlarm = {
        previewPlayer.stop()
        val alarmToSave = Alarm(
            id = existingAlarm?.id ?: 0L,
            hour = timePickerState.hour,
            minute = timePickerState.minute,
            label = label.trim(),
            daysMask = daysMask,
            enabled = true,
            toneType = selectedTone.name,
            toneUri = customToneUri,
            volumePercent = volumePercent.coerceIn(10, 100),
            gradualVolume = gradualVolume,
            vibrate = vibrate,
            snoozeMinutes = snoozeMinutes,
            snoozeMaxCount = snoozeMaxCount,
            mathChallenge = mathChallenge,
            snoozeCount = 0
        )
        viewModel.saveAlarm(alarmToSave) {
            onNavigateBack()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = if (isEditing) "تعديل المنبه" else "منبه جديد",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = {
                        previewPlayer.stop()
                        onNavigateBack()
                    }) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                },
                actions = {
                    TextButton(onClick = saveCurrentAlarm) {
                        Icon(imageVector = Icons.Filled.Check, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("حفظ", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Time Picker Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        TimePicker(state = timePickerState)
                    }
                }
            }

            // Label
            OutlinedTextField(
                value = label,
                onValueChange = { label = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text("عنوان المنبه (اختياري)") },
                placeholder = { Text("مثال: العمل، الفجر، الدوام") },
                singleLine = true,
                shape = RoundedCornerShape(16.dp)
            )

            // Repeat Days
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "أيام التكرار",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = daysMask == WeekdayMask.ALL_DAYS,
                            onClick = {
                                daysMask = if (daysMask == WeekdayMask.ALL_DAYS) 0 else WeekdayMask.ALL_DAYS
                            },
                            label = { Text("كل يوم") }
                        )
                        FilterChip(
                            selected = daysMask == WeekdayMask.WORK_DAYS,
                            onClick = {
                                daysMask = if (daysMask == WeekdayMask.WORK_DAYS) 0 else WeekdayMask.WORK_DAYS
                            },
                            label = { Text("أيام العمل (السبت–الأربعاء)") }
                        )
                    }

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        WeekdayMask.orderedWeekdays.forEach { day ->
                            val selected = WeekdayMask.isBitEnabled(daysMask, day.bit)
                            FilterChip(
                                selected = selected,
                                onClick = {
                                    daysMask = WeekdayMask.toggleBit(daysMask, day.bit)
                                },
                                label = { Text(day.fullName) }
                            )
                        }
                    }

                    Text(
                        text = if (daysMask == 0) {
                            "مرة واحدة: لا توجد أيام محددة، سيرن المنبه مرة واحدة ثم يتوقف تلقائياً."
                        } else {
                            "التكرار: ${WeekdayMask.formatDaysSummaryArabic(daysMask)}"
                        },
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            // Sound & Volume
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "نغمة التنبيه",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    ToneType.builtInTones.forEach { tone ->
                        val isSelected = selectedTone == tone
                        val isPlaying = playingTone == tone
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedTone = tone }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RadioButton(
                                selected = isSelected,
                                onClick = { selectedTone = tone }
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = tone.arabicTitle,
                                    style = MaterialTheme.typography.bodyLarge,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                                Text(
                                    text = tone.arabicDescription,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            IconButton(
                                onClick = {
                                    previewPlayer.togglePreview(tone, null, volumePercent)
                                }
                            ) {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                    contentDescription = if (isPlaying) "إيقاف المعاينة" else "تشغيل المعاينة",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    // Custom audio file row
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                if (customToneUri != null) {
                                    selectedTone = ToneType.CUSTOM_URI
                                } else {
                                    openAudioLauncher.launch(arrayOf("audio/*"))
                                }
                            },
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedTone == ToneType.CUSTOM_URI,
                            onClick = {
                                if (customToneUri != null) {
                                    selectedTone = ToneType.CUSTOM_URI
                                } else {
                                    openAudioLauncher.launch(arrayOf("audio/*"))
                                }
                            }
                        )
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "ملف صوتي من الهاتف",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = if (selectedTone == ToneType.CUSTOM_URI) FontWeight.Bold else FontWeight.Normal
                            )
                            Text(
                                text = customFileName ?: "اختر أي ملف صوتي (MP3, WAV, M4A...)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        if (!customToneUri.isNullOrBlank()) {
                            val isPlayingCustom = playingTone == ToneType.CUSTOM_URI
                            IconButton(
                                onClick = {
                                    previewPlayer.togglePreview(
                                        ToneType.CUSTOM_URI,
                                        customToneUri,
                                        volumePercent
                                    )
                                }
                            ) {
                                Icon(
                                    imageVector = if (isPlayingCustom) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                    contentDescription = if (isPlayingCustom) "إيقاف المعاينة" else "معاينة الملف",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        }
                    }

                    OutlinedButton(
                        onClick = { openAudioLauncher.launch(arrayOf("audio/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(imageVector = Icons.Filled.AudioFile, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (customToneUri == null) "اختيار نغمة من الهاتف" else "تغيير الملف الصوتي"
                        )
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "مستوى الصوت",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "$volumePercent%",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }

                    Slider(
                        value = volumePercent.toFloat(),
                        onValueChange = { newVal ->
                            volumePercent = newVal.roundToInt().coerceIn(10, 100)
                            previewPlayer.updateVolume(volumePercent)
                        },
                        valueRange = 10f..100f
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "رفع الصوت تدريجيا",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "يرتفع الصوت منخفضاً ثم يصل للمستوى المختار خلال 20 ثانية",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = gradualVolume,
                            onCheckedChange = { gradualVolume = it }
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "الاهتزاز",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium
                            )
                            Text(
                                text = "اهتزاز متكرر مع الرنين",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = vibrate,
                            onCheckedChange = { vibrate = it }
                        )
                    }
                }
            }

            // Snooze / Repeat Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "تكرار التنبيه (الغفوة)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    Text(
                        text = "مدة الغفوة",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 3, 5, 10, 15).forEach { mins ->
                            val labelMins = when (mins) {
                                1 -> "دقيقة واحدة"
                                3 -> "3 دقائق"
                                5 -> "5 دقائق"
                                10 -> "10 دقائق"
                                else -> "15 دقيقة"
                            }
                            FilterChip(
                                selected = snoozeMinutes == mins,
                                onClick = { snoozeMinutes = mins },
                                label = { Text(labelMins) }
                            )
                        }
                    }

                    Text(
                        text = "عدد مرات التكرار",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium
                    )

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(1, 2, 3, 5, 10, -1).forEach { count ->
                            val countLabel = if (count == -1) "بلا حدود" else "$count"
                            FilterChip(
                                selected = snoozeMaxCount == count,
                                onClick = { snoozeMaxCount = count },
                                label = { Text(countLabel) }
                            )
                        }
                    }
                }
            }

            // Math Challenge Section
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "تحدي الإيقاف",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "لإيقاف المنبه نهائياً يجب حل 3 مسائل حسابية بسيطة. زر الغفوة يبقى بضغطة واحدة.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Switch(
                        checked = mathChallenge,
                        onCheckedChange = { mathChallenge = it }
                    )
                }
            }

            // Primary Save Button
            Button(
                onClick = saveCurrentAlarm,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text(
                    text = if (isEditing) "حفظ التعديلات" else "حفظ وتفعيل المنبه",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            }

            if (isEditing && existingAlarm != null) {
                OutlinedButton(
                    onClick = { showDeleteConfirm = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Icon(imageVector = Icons.Filled.Delete, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("حذف المنبه", fontWeight = FontWeight.Bold)
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showDeleteConfirm && existingAlarm != null) {
        AlertDialog(
            onDismissRequest = { showDeleteConfirm = false },
            title = { Text("حذف المنبه؟") },
            text = { Text("هل تريد حذف هذا المنبه نهائياً؟") },
            confirmButton = {
                TextButton(
                    onClick = {
                        previewPlayer.stop()
                        showDeleteConfirm = false
                        viewModel.deleteAlarm(existingAlarm!!) {
                            onNavigateBack()
                        }
                    }
                ) {
                    Text("حذف", color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteConfirm = false }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

private fun resolveDisplayName(context: Context, uriString: String): String {
    return try {
        val uri = Uri.parse(uriString)
        context.contentResolver.query(
            uri,
            arrayOf(OpenableColumns.DISPLAY_NAME),
            null,
            null,
            null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) return cursor.getString(idx) ?: "ملف صوتي مختار"
            }
        }
        uri.lastPathSegment ?: "ملف صوتي مختار"
    } catch (_: Exception) {
        "ملف صوتي مختار"
    }
}
