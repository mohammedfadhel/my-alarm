package com.wakeup.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.AlarmOff
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SwipeToDismissBox
import androidx.compose.material3.SwipeToDismissBoxValue
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.rememberSwipeToDismissBoxState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wakeup.app.data.model.Alarm
import com.wakeup.app.ui.viewmodel.AlarmViewModel
import com.wakeup.app.util.AlarmTimeCalculator
import com.wakeup.app.util.WeekdayMask
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlarmListScreen(
    viewModel: AlarmViewModel,
    onAddAlarm: () -> Unit,
    onEditAlarm: (Long) -> Unit,
    onOpenSettings: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val alarms by viewModel.alarms.collectAsStateWithLifecycle()
    val permissionStatus by viewModel.permissionStatus.collectAsStateWithLifecycle()

    var nowMillis by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var alarmPendingDelete by remember { mutableStateOf<Alarm?>(null) }

    LaunchedEffect(Unit) {
        while (true) {
            nowMillis = System.currentTimeMillis()
            delay(20_000L)
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                nowMillis = System.currentTimeMillis()
                viewModel.refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val nextAlarmPair = remember(alarms, nowMillis) {
        alarms
            .filter { it.enabled }
            .map { alarm ->
                val trigger = AlarmTimeCalculator.computeNextTriggerMillis(
                    hour = alarm.hour,
                    minute = alarm.minute,
                    daysMask = alarm.daysMask,
                    nowMillis = nowMillis
                )
                alarm to trigger
            }
            .minByOrNull { it.second }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "منبهي",
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(
                            imageVector = Icons.Outlined.Settings,
                            contentDescription = "الإعدادات وفحص الأذونات"
                        )
                    }
                }
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddAlarm,
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = MaterialTheme.colorScheme.onPrimary
            ) {
                Icon(
                    imageVector = Icons.Filled.Add,
                    contentDescription = "إضافة منبه جديد"
                )
            }
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(
                start = 16.dp,
                end = 16.dp,
                top = 8.dp,
                bottom = 96.dp
            ),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (!permissionStatus.exactAlarmsGranted) {
                item(key = "exact_alarm_warning") {
                    ExactAlarmWarningCard(onClick = onOpenSettings)
                }
            }

            item(key = "next_alarm_banner") {
                NextAlarmBanner(
                    nextAlarm = nextAlarmPair?.first,
                    nextTriggerMillis = nextAlarmPair?.second,
                    nowMillis = nowMillis
                )
            }

            if (alarms.isEmpty()) {
                item(key = "empty_state") {
                    EmptyAlarmsState(onAddAlarm = onAddAlarm)
                }
            } else {
                items(
                    items = alarms,
                    key = { it.id }
                ) { alarm ->
                    val dismissState = rememberSwipeToDismissBoxState(
                        confirmValueChange = { value ->
                            if (value != SwipeToDismissBoxValue.Settled) {
                                alarmPendingDelete = alarm
                            }
                            false
                        }
                    )

                    SwipeToDismissBox(
                        state = dismissState,
                        backgroundContent = {
                            Box(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.errorContainer)
                                    .padding(horizontal = 24.dp),
                                contentAlignment = Alignment.CenterEnd
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Delete,
                                    contentDescription = "حذف المنبه",
                                    tint = MaterialTheme.colorScheme.onErrorContainer
                                )
                            }
                        }
                    ) {
                        AlarmCard(
                            alarm = alarm,
                            nowMillis = nowMillis,
                            onClick = { onEditAlarm(alarm.id) },
                            onToggle = { checked ->
                                viewModel.toggleAlarm(alarm, checked)
                            },
                            onRequestDelete = {
                                alarmPendingDelete = alarm
                            }
                        )
                    }
                }
            }
        }
    }

    val pendingDelete = alarmPendingDelete
    if (pendingDelete != null) {
        val (timeStr, period) = AlarmTimeCalculator.formatTimeArabic(
            context,
            pendingDelete.hour,
            pendingDelete.minute
        )
        val fullTime = if (period != null) "$timeStr $period" else timeStr
        AlertDialog(
            onDismissRequest = { alarmPendingDelete = null },
            title = { Text("حذف المنبه؟") },
            text = {
                val labelText = if (pendingDelete.label.isNotBlank()) {
                    " (${pendingDelete.label})"
                } else {
                    ""
                }
                Text("هل تريد بالتأكيد حذف منبه الساعة $fullTime$labelText؟")
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        viewModel.deleteAlarm(pendingDelete)
                        alarmPendingDelete = null
                    }
                ) {
                    Text(
                        text = "حذف",
                        color = MaterialTheme.colorScheme.error,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            dismissButton = {
                TextButton(onClick = { alarmPendingDelete = null }) {
                    Text("إلغاء")
                }
            }
        )
    }
}

@Composable
private fun ExactAlarmWarningCard(onClick: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.errorContainer
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Warning,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.error,
                modifier = Modifier.size(28.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = "إذن المنبهات الدقيقة غير مفعل!",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "قد يتأخر المنبه بدون هذا الإذن. اضغط هنا لتفعيل \"المنبهات والتذكيرات\" الآن.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onErrorContainer
                )
            }
        }
    }
}

@Composable
private fun NextAlarmBanner(
    nextAlarm: Alarm?,
    nextTriggerMillis: Long?,
    nowMillis: Long
) {
    val context = LocalContext.current
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (nextAlarm != null) {
                MaterialTheme.colorScheme.primaryContainer
            } else {
                MaterialTheme.colorScheme.surfaceVariant
            }
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Icon(
                imageVector = if (nextAlarm != null) Icons.Filled.Alarm else Icons.Filled.AlarmOff,
                contentDescription = null,
                tint = if (nextAlarm != null) {
                    MaterialTheme.colorScheme.onPrimaryContainer
                } else {
                    MaterialTheme.colorScheme.onSurfaceVariant
                },
                modifier = Modifier.size(30.dp)
            )
            Column(modifier = Modifier.weight(1f)) {
                if (nextAlarm != null && nextTriggerMillis != null) {
                    val countdown = AlarmTimeCalculator.formatBannerCountdownArabic(
                        triggerMillis = nextTriggerMillis,
                        nowMillis = nowMillis
                    )
                    val (timeText, period) = AlarmTimeCalculator.formatTimeArabic(
                        context,
                        nextAlarm.hour,
                        nextAlarm.minute
                    )
                    val formattedTime = if (period != null) "$timeText $period" else timeText
                    val labelPart = if (nextAlarm.label.isNotBlank()) " • ${nextAlarm.label}" else ""

                    Text(
                        text = countdown,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "الساعة $formattedTime$labelPart",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                    )
                } else {
                    Text(
                        text = "لا توجد منبهات مفعلة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "فعّل منبهاً أو أضف منبهاً جديداً للاستيقاظ في الوقت المحدد",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                    )
                }
            }
        }
    }
}

@Composable
private fun AlarmCard(
    alarm: Alarm,
    nowMillis: Long,
    onClick: () -> Unit,
    onToggle: (Boolean) -> Unit,
    onRequestDelete: () -> Unit
) {
    val context = LocalContext.current
    val (timeText, period) = AlarmTimeCalculator.formatTimeArabic(
        context,
        alarm.hour,
        alarm.minute
    )
    val daysSummary = WeekdayMask.formatDaysSummaryArabic(alarm.daysMask)
    val nextRingText = if (alarm.enabled) {
        val nextMillis = AlarmTimeCalculator.computeNextTriggerMillis(
            hour = alarm.hour,
            minute = alarm.minute,
            daysMask = alarm.daysMask,
            nowMillis = nowMillis
        )
        AlarmTimeCalculator.formatRemainingTimeArabic(nextMillis, nowMillis)
    } else {
        "متوقف"
    }

    val contentAlpha = if (alarm.enabled) 1f else 0.55f

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.Bottom,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = timeText,
                        fontSize = 38.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = contentAlpha),
                        lineHeight = 42.sp
                    )
                    if (period != null) {
                        Text(
                            text = period,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.primary.copy(alpha = contentAlpha),
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                    }
                }

                if (alarm.label.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = alarm.label,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = contentAlpha),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        text = daysSummary,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.primary.copy(alpha = contentAlpha)
                    )
                    if (alarm.mathChallenge) {
                        Icon(
                            imageVector = Icons.Filled.Calculate,
                            contentDescription = "تحدي الإيقاف",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.secondary.copy(alpha = contentAlpha)
                        )
                    }
                    if (alarm.gradualVolume) {
                        Icon(
                            imageVector = Icons.Filled.GraphicEq,
                            contentDescription = "رفع الصوت تدريجياً",
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.secondary.copy(alpha = contentAlpha)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = nextRingText,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = contentAlpha)
                )
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Switch(
                    checked = alarm.enabled,
                    onCheckedChange = onToggle
                )
                IconButton(onClick = onRequestDelete) {
                    Icon(
                        imageVector = Icons.Outlined.DeleteOutline,
                        contentDescription = "حذف المنبه",
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}

@Composable
private fun EmptyAlarmsState(onAddAlarm: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 24.dp),
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Filled.Alarm,
                contentDescription = null,
                modifier = Modifier.size(56.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(14.dp))
            Text(
                text = "لا توجد منبهات بعد",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "اضغط على زر + لإضافة منبه صباحي موثوق بصوت قوي",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(16.dp))
            TextButton(onClick = onAddAlarm) {
                Icon(imageVector = Icons.Filled.Add, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text("إضافة منبه جديد", fontWeight = FontWeight.Bold)
            }
        }
    }
}
