package com.wakeup.app.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.wakeup.app.ui.viewmodel.AlarmViewModel
import com.wakeup.app.util.PermissionChecker
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsAndPermissionsScreen(
    viewModel: AlarmViewModel,
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val permissionStatus by viewModel.permissionStatus.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { granted ->
        viewModel.refreshPermissions()
        if (!granted) {
            PermissionChecker.launchSettingsSafely(
                context,
                PermissionChecker.buildAppNotificationSettingsIntent(context)
            )
        }
    }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                viewModel.refreshPermissions()
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "الإعدادات وفحص الأذونات",
                        fontWeight = FontWeight.Bold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع"
                        )
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Test Alarm Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.NotificationsActive,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "اختبار المنبه الآن",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Text(
                        text = "يجدول منبهاً تجريبياً يرن بعد 10 ثوانٍ للتأكد من الصوت وشاشة القفل. يمكنك قفل الشاشة بعد الضغط.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                    Button(
                        onClick = {
                            viewModel.scheduleTestAlarm()
                            scope.launch {
                                snackbarHostState.showSnackbar("سيرن المنبه التجريبي خلال 10 ثوانٍ...")
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("اختبار المنبه الآن (بعد 10 ثوانٍ)", fontWeight = FontWeight.Bold)
                    }
                }
            }

            // Permissions Checklist
            Text(
                text = "فحص الأذونات المطلوبة للموثوقية القصوى",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )

            PermissionItemCard(
                title = "إذن الإشعارات (Android 13+)",
                description = "مطلوب لعرض إشعار المنبه وإطلاق شاشة الرنين والتنبيه بالمنبهات الفائتة.",
                granted = permissionStatus.notificationsGranted,
                buttonText = if (permissionStatus.notificationsGranted) "مفعل" else "تفعيل الإشعارات",
                onAction = {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    } else {
                        PermissionChecker.launchSettingsSafely(
                            context,
                            PermissionChecker.buildAppNotificationSettingsIntent(context)
                        )
                    }
                }
            )

            PermissionItemCard(
                title = "المنبهات والتذكيرات الدقيقة",
                description = "يسمح بجدولة المنبه في الدقيقة المحددة تماماً وتجاوز وضع السكون (Doze).",
                granted = permissionStatus.exactAlarmsGranted,
                buttonText = if (permissionStatus.exactAlarmsGranted) "مفعل" else "فتح المنبهات والتذكيرات",
                onAction = {
                    PermissionChecker.launchSettingsSafely(
                        context,
                        PermissionChecker.buildExactAlarmSettingsIntent(context)
                    )
                }
            )

            PermissionItemCard(
                title = "إشعارات ملء الشاشة (Android 14+)",
                description = "مطلوب لفتح شاشة المنبه تلقائياً فوق شاشة القفل.",
                granted = permissionStatus.fullScreenIntentGranted,
                buttonText = if (permissionStatus.fullScreenIntentGranted) "مفعل" else "تفعيل ملء الشاشة",
                onAction = {
                    PermissionChecker.launchSettingsSafely(
                        context,
                        PermissionChecker.buildFullScreenIntentSettingsIntent(context)
                    )
                }
            )

            PermissionItemCard(
                title = "الظهور فوق التطبيقات الأخرى",
                description = "يضمن ظهور شاشة الرنين فوراً حتى أثناء استخدام الهاتف وهو مفتوح.",
                granted = permissionStatus.overlayGranted,
                buttonText = if (permissionStatus.overlayGranted) "مفعل" else "تفعيل الظهور فوق التطبيقات",
                onAction = {
                    PermissionChecker.launchSettingsSafely(
                        context,
                        PermissionChecker.buildOverlaySettingsIntent(context)
                    )
                }
            )

            PermissionItemCard(
                title = "استثناء تحسين البطارية",
                description = "يمنع النظام من إيقاف خدمة المنبه في الخلفية ليلاً.",
                granted = permissionStatus.batteryOptimizationIgnored,
                buttonText = if (permissionStatus.batteryOptimizationIgnored) "مفعل" else "إلغاء قيود البطارية",
                onAction = {
                    PermissionChecker.launchSettingsSafely(
                        context,
                        PermissionChecker.buildBatteryOptimizationIntent(context)
                    )
                }
            )

            // Xiaomi / Redmi Note
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                )
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.PhoneAndroid,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                        Text(
                            text = "ملاحظة هامة لهواتف شاومي وريدمي (Xiaomi / Redmi)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSecondaryContainer
                        )
                    }

                    Text(
                        text = "لضمان رنين المنبه على واجهة MIUI / HyperOS عند إغلاق التطبيق أو قفل الشاشة، يرجى تفعيل الخيارات التالية من صفحة تفاصيل وأذونات التطبيق:\n" +
                            "• التشغيل التلقائي (Autostart): مفعّل\n" +
                            "• موفر البطارية: \"بلا قيود\" (No restrictions)\n" +
                            "• أذونات أخرى: تفعيل \"العرض على شاشة القفل\" و\"عرض النوافذ المنبثقة أثناء العمل في الخلفية\"",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSecondaryContainer
                    )

                    OutlinedButton(
                        onClick = {
                            PermissionChecker.launchSettingsSafely(
                                context,
                                PermissionChecker.buildAppDetailsIntent(context)
                            )
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text("فتح صفحة تفاصيل التطبيق", fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun PermissionItemCard(
    title: String,
    description: String,
    granted: Boolean,
    buttonText: String,
    onAction: () -> Unit
) {
    val statusColor = if (granted) Color(0xFF16A34A) else MaterialTheme.colorScheme.error

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = if (granted) Icons.Filled.CheckCircle else Icons.Filled.Cancel,
                    contentDescription = if (granted) "ممنوح" else "مطلوب",
                    tint = statusColor,
                    modifier = Modifier.size(26.dp)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = if (granted) "الحالة: مفعّل وجاهز" else "الحالة: غير مفعّل — يرجى التفعيل",
                        style = MaterialTheme.typography.labelMedium,
                        color = statusColor,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }

            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (!granted) {
                Button(
                    onClick = onAction,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(buttonText, fontWeight = FontWeight.Bold)
                }
            } else {
                OutlinedButton(
                    onClick = onAction,
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("مراجعة الإعداد")
                }
            }
        }
    }
}
