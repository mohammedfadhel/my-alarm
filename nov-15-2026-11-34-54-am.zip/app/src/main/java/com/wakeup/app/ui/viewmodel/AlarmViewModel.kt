package com.wakeup.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.wakeup.app.AlarmApplication
import com.wakeup.app.data.model.Alarm
import com.wakeup.app.util.PermissionChecker
import com.wakeup.app.util.PermissionStatusSummary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AlarmViewModel(application: Application) : AndroidViewModel(application) {

    private val app = application as AlarmApplication
    private val repository = app.repository

    val alarms: StateFlow<List<Alarm>> = repository.allAlarms.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000L),
        initialValue = emptyList()
    )

    private val _permissionStatus = MutableStateFlow(PermissionChecker.getStatus(application))
    val permissionStatus: StateFlow<PermissionStatusSummary> = _permissionStatus.asStateFlow()

    private val _shouldShowFirstLaunchCheck = MutableStateFlow(
        !repository.protectedStore.isFirstLaunchPermissionCheckShown()
    )
    val shouldShowFirstLaunchCheck: StateFlow<Boolean> = _shouldShowFirstLaunchCheck.asStateFlow()

    fun markFirstLaunchCheckConsumed() {
        repository.protectedStore.markFirstLaunchPermissionCheckShown()
        _shouldShowFirstLaunchCheck.value = false
    }

    fun refreshPermissions() {
        _permissionStatus.value = PermissionChecker.getStatus(app)
    }

    suspend fun getAlarmById(id: Long): Alarm? {
        return repository.getAlarmById(id)
    }

    fun saveAlarm(alarm: Alarm, onSaved: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.saveAlarm(alarm)
            launch(Dispatchers.Main) {
                onSaved()
            }
        }
    }

    fun toggleAlarm(alarm: Alarm, enabled: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.toggleAlarmEnabled(alarm, enabled)
        }
    }

    fun deleteAlarm(alarm: Alarm, onDeleted: () -> Unit = {}) {
        viewModelScope.launch(Dispatchers.IO) {
            repository.deleteAlarm(alarm)
            launch(Dispatchers.Main) {
                onDeleted()
            }
        }
    }

    fun scheduleTestAlarm() {
        repository.scheduleTestAlarm()
    }

    fun rescheduleAll() {
        viewModelScope.launch(Dispatchers.IO) {
            repository.rescheduleAllEnabledAlarms()
        }
    }
}
