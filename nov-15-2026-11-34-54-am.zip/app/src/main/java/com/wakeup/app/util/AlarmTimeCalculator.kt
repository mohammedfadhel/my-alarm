package com.wakeup.app.util

import android.content.Context
import android.text.format.DateFormat
import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.Locale

data class ArabicWeekday(
    val bit: Int,
    val dayOfWeek: DayOfWeek,
    val fullName: String,
    val shortName: String
)

object WeekdayMask {
    const val SATURDAY = 1 shl 0
    const val SUNDAY = 1 shl 1
    const val MONDAY = 1 shl 2
    const val TUESDAY = 1 shl 3
    const val WEDNESDAY = 1 shl 4
    const val THURSDAY = 1 shl 5
    const val FRIDAY = 1 shl 6

    const val WORK_DAYS = SATURDAY or SUNDAY or MONDAY or TUESDAY or WEDNESDAY
    const val ALL_DAYS = SATURDAY or SUNDAY or MONDAY or TUESDAY or WEDNESDAY or THURSDAY or FRIDAY

    val orderedWeekdays: List<ArabicWeekday> = listOf(
        ArabicWeekday(SATURDAY, DayOfWeek.SATURDAY, "السبت", "سبت"),
        ArabicWeekday(SUNDAY, DayOfWeek.SUNDAY, "الأحد", "أحد"),
        ArabicWeekday(MONDAY, DayOfWeek.MONDAY, "الاثنين", "اثنين"),
        ArabicWeekday(TUESDAY, DayOfWeek.TUESDAY, "الثلاثاء", "ثلاثاء"),
        ArabicWeekday(WEDNESDAY, DayOfWeek.WEDNESDAY, "الأربعاء", "أربعاء"),
        ArabicWeekday(THURSDAY, DayOfWeek.THURSDAY, "الخميس", "خميس"),
        ArabicWeekday(FRIDAY, DayOfWeek.FRIDAY, "الجمعة", "جمعة")
    )

    fun bitForDayOfWeek(dayOfWeek: DayOfWeek): Int {
        return when (dayOfWeek) {
            DayOfWeek.SATURDAY -> SATURDAY
            DayOfWeek.SUNDAY -> SUNDAY
            DayOfWeek.MONDAY -> MONDAY
            DayOfWeek.TUESDAY -> TUESDAY
            DayOfWeek.WEDNESDAY -> WEDNESDAY
            DayOfWeek.THURSDAY -> THURSDAY
            DayOfWeek.FRIDAY -> FRIDAY
        }
    }

    fun isDayEnabled(daysMask: Int, dayOfWeek: DayOfWeek): Boolean {
        return (daysMask and bitForDayOfWeek(dayOfWeek)) != 0
    }

    fun isBitEnabled(daysMask: Int, bit: Int): Boolean {
        return (daysMask and bit) != 0
    }

    fun toggleBit(daysMask: Int, bit: Int): Int {
        return daysMask xor bit
    }

    fun formatDaysSummaryArabic(daysMask: Int): String {
        val masked = daysMask and ALL_DAYS
        if (masked == 0) return "مرة واحدة"
        if (masked == ALL_DAYS) return "كل يوم"

        val selectedIndices = orderedWeekdays.indices.filter { index ->
            isBitEnabled(masked, orderedWeekdays[index].bit)
        }
        if (selectedIndices.size >= 3) {
            val isContiguous = selectedIndices.zipWithNext().all { (a, b) -> b == a + 1 }
            if (isContiguous) {
                val first = orderedWeekdays[selectedIndices.first()].fullName
                val last = orderedWeekdays[selectedIndices.last()].fullName
                return "$first – $last"
            }
        }
        return selectedIndices.joinToString("، ") { orderedWeekdays[it].fullName }
    }
}

object AlarmTimeCalculator {

    fun computeNextTriggerMillis(
        hour: Int,
        minute: Int,
        daysMask: Int,
        nowMillis: Long = System.currentTimeMillis(),
        zoneId: ZoneId = ZoneId.systemDefault()
    ): Long {
        val now = ZonedDateTime.ofInstant(Instant.ofEpochMilli(nowMillis), zoneId)
        val todayCandidate = now
            .withHour(hour.coerceIn(0, 23))
            .withMinute(minute.coerceIn(0, 59))
            .withSecond(0)
            .withNano(0)

        val masked = daysMask and WeekdayMask.ALL_DAYS
        if (masked == 0) {
            val next = if (todayCandidate.isAfter(now)) {
                todayCandidate
            } else {
                todayCandidate.plusDays(1)
            }
            return next.toInstant().toEpochMilli()
        }

        for (offset in 0L..7L) {
            val candidate = todayCandidate.plusDays(offset)
            if (WeekdayMask.isDayEnabled(masked, candidate.dayOfWeek) && candidate.isAfter(now)) {
                return candidate.toInstant().toEpochMilli()
            }
        }

        return todayCandidate.plusDays(7).toInstant().toEpochMilli()
    }

    fun formatTimeArabic(context: Context, hour: Int, minute: Int): Pair<String, String?> {
        val is24Hour = DateFormat.is24HourFormat(context)
        return formatTimeWith24HourFlag(hour, minute, is24Hour)
    }

    fun formatTimeWith24HourFlag(hour: Int, minute: Int, is24Hour: Boolean): Pair<String, String?> {
        val safeHour = hour.coerceIn(0, 23)
        val safeMinute = minute.coerceIn(0, 59)
        return if (is24Hour) {
            String.format(Locale.US, "%02d:%02d", safeHour, safeMinute) to null
        } else {
            val period = if (safeHour < 12) "ص" else "م"
            val displayHour = when {
                safeHour == 0 -> 12
                safeHour > 12 -> safeHour - 12
                else -> safeHour
            }
            String.format(Locale.US, "%02d:%02d", displayHour, safeMinute) to period
        }
    }

    fun formatRemainingTimeArabic(
        triggerMillis: Long,
        nowMillis: Long = System.currentTimeMillis()
    ): String {
        val diffMillis = (triggerMillis - nowMillis).coerceAtLeast(0L)
        if (diffMillis < 60_000L) {
            return "يرن بعد أقل من دقيقة"
        }

        val totalMinutes = (diffMillis + 30_000L) / 60_000L
        val days = totalMinutes / (24 * 60)
        val hours = (totalMinutes % (24 * 60)) / 60
        val minutes = totalMinutes % 60

        val parts = mutableListOf<String>()
        if (days > 0) parts += formatArabicUnit(days, "يوم", "يومان", "أيام", "يوماً")
        if (hours > 0) parts += formatArabicUnit(hours, "ساعة", "ساعتان", "ساعات", "ساعة")
        if (minutes > 0 || parts.isEmpty()) {
            parts += formatArabicUnit(minutes, "دقيقة", "دقيقتان", "دقائق", "دقيقة")
        }

        return "يرن بعد ${parts.joinToString(" و")}"
    }

    fun formatBannerCountdownArabic(
        triggerMillis: Long,
        nowMillis: Long = System.currentTimeMillis()
    ): String {
        val diffMillis = (triggerMillis - nowMillis).coerceAtLeast(0L)
        if (diffMillis < 60_000L) {
            return "المنبه القادم بعد أقل من دقيقة"
        }

        val totalMinutes = (diffMillis + 30_000L) / 60_000L
        val days = totalMinutes / (24 * 60)
        val hours = (totalMinutes % (24 * 60)) / 60
        val minutes = totalMinutes % 60

        val parts = mutableListOf<String>()
        if (days > 0) parts += formatArabicUnit(days, "يوم", "يومان", "أيام", "يوماً")
        if (hours > 0) parts += formatArabicUnit(hours, "ساعة", "ساعتان", "ساعات", "ساعة")
        if (minutes > 0 || parts.isEmpty()) {
            parts += formatArabicUnit(minutes, "دقيقة", "دقيقتان", "دقائق", "دقيقة")
        }

        return "المنبه القادم بعد ${parts.joinToString(" و")}"
    }

    private fun formatArabicUnit(
        count: Long,
        singular: String,
        dual: String,
        pluralFew: String,
        pluralMany: String
    ): String {
        return when {
            count == 1L -> singular
            count == 2L -> dual
            count in 3L..10L -> "$count $pluralFew"
            else -> "$count $pluralMany"
        }
    }
}
