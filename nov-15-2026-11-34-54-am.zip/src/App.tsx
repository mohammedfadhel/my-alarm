import { useMemo, useState } from 'react';
import {
  Check,
  Copy,
  Download,
  FileCode2,
  FolderTree,
  Search,
  ShieldCheck,
  Volume2,
} from 'lucide-react';
import { ANDROID_PROJECT_FILES } from './generated/androidFiles';

export default function App() {
  const [selectedPath, setSelectedPath] = useState<string>(
    'app/src/main/AndroidManifest.xml'
  );
  const [query, setQuery] = useState('');
  const [copied, setCopied] = useState(false);

  const filteredFiles = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return ANDROID_PROJECT_FILES;
    return ANDROID_PROJECT_FILES.filter((file) =>
      file.path.toLowerCase().includes(q)
    );
  }, [query]);

  const activeFile = useMemo(() => {
    return (
      ANDROID_PROJECT_FILES.find((f) => f.path === selectedPath) ??
      ANDROID_PROJECT_FILES[0]
    );
  }, [selectedPath]);

  const handleCopy = async () => {
    if (!activeFile) return;
    try {
      await navigator.clipboard.writeText(activeFile.content);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      // Ignore clipboard failures in restricted iframes
    }
  };

  const totalLines = useMemo(
    () => ANDROID_PROJECT_FILES.reduce((acc, f) => acc + f.lines, 0),
    []
  );

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-slate-950 text-slate-100 flex flex-col"
    >
      <header className="border-b border-slate-800 bg-slate-900/90 backdrop-blur">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-3">
              <span className="inline-flex h-10 w-10 items-center justify-center rounded-xl bg-amber-500/20 text-amber-400 font-bold text-lg">
                م
              </span>
              <div>
                <h1 className="text-xl font-bold text-white">
                  منبهي — مشروع Android Studio أصلي (Kotlin + Jetpack Compose)
                </h1>
                <p className="text-xs text-slate-400 mt-0.5">
                  Package: <span dir="ltr" className="font-mono text-amber-300">com.wakeup.app</span> • minSdk 26 • targetSdk 35 • Room + KSP • {ANDROID_PROJECT_FILES.length} ملفاً ({totalLines.toLocaleString()} سطراً)
                </p>
              </div>
            </div>
          </div>

          <a
            href="/monabihi-android-project.zip"
            download="Monabihi-Android-Project.zip"
            className="inline-flex items-center gap-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-5 py-2.5 text-sm transition-colors"
          >
            <Download className="w-4 h-4" />
            تحميل مشروع Android Studio (ZIP)
          </a>
        </div>
      </header>

      <div className="max-w-7xl w-full mx-auto px-4 sm:px-6 py-4 grid grid-cols-1 md:grid-cols-3 gap-3">
        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3.5 flex items-start gap-3">
          <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed text-slate-300">
            <div className="font-semibold text-white mb-0.5">معمارية موثوقية عالية</div>
            <span>
              جدولة مزدوجة (<span dir="ltr" className="font-mono">setAlarmClock</span> + <span dir="ltr" className="font-mono">setExactAndAllowWhileIdle</span>)، خدمة Foreground، <span dir="ltr" className="font-mono">PARTIAL_WAKE_LOCK</span>، وإعادة جدولة بعد الإقلاع وتحديث الوقت.
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3.5 flex items-start gap-3">
          <Volume2 className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed text-slate-300">
            <div className="font-semibold text-white mb-0.5">صوت عالٍ بدون ملفات خارجية</div>
            <span>
              6 نغمات مركّبة بـ <span dir="ltr" className="font-mono">AudioTrack</span> على <span dir="ltr" className="font-mono">STREAM_ALARM</span> مع رفع تلقائي لمستوى الصوت واسترجاعه، وتدرج 20 ثانية، واختيار ملف صوتي مع رجوع احتياطي تلقائي.
            </span>
          </div>
        </div>

        <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3.5 flex items-start gap-3">
          <FolderTree className="w-5 h-5 text-sky-400 shrink-0 mt-0.5" />
          <div className="text-xs leading-relaxed text-slate-300">
            <div className="font-semibold text-white mb-0.5">التشغيل في Android Studio</div>
            <span>
              فك ضغط ملف ZIP ثم افتح مجلد <span dir="ltr" className="font-mono">Monabihi</span> مباشرة في Android Studio (Gradle 8.10 / AGP 8.7.3 / Kotlin 2.0.21).
            </span>
          </div>
        </div>
      </div>

      <main className="max-w-7xl w-full mx-auto px-4 sm:px-6 pb-6 flex-1 grid grid-cols-1 lg:grid-cols-12 gap-4 min-h-0">
        <aside className="lg:col-span-4 rounded-xl border border-slate-800 bg-slate-900/80 flex flex-col overflow-hidden max-h-[70vh]">
          <div className="p-3 border-b border-slate-800">
            <div className="relative">
              <Search className="w-4 h-4 text-slate-400 absolute right-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="تصفية الملفات..."
                className="w-full rounded-lg bg-slate-950 border border-slate-800 pr-9 pl-3 py-2 text-xs text-slate-200 placeholder:text-slate-500 focus:outline-none focus:border-amber-500"
              />
            </div>
          </div>

          <div className="overflow-y-auto flex-1 p-2 space-y-1">
            {filteredFiles.map((file) => {
              const isSelected = activeFile?.path === file.path;
              return (
                <button
                  key={file.path}
                  type="button"
                  onClick={() => setSelectedPath(file.path)}
                  className={`w-full text-left px-3 py-2 rounded-lg text-xs font-mono transition-colors flex items-center justify-between gap-2 ${
                    isSelected
                      ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                      : 'text-slate-300 hover:bg-slate-800/70'
                  }`}
                  dir="ltr"
                >
                  <span className="truncate flex items-center gap-2">
                    <FileCode2 className="w-3.5 h-3.5 shrink-0 opacity-75" />
                    <span className="truncate">{file.path}</span>
                  </span>
                  <span className="text-[10px] text-slate-500 shrink-0">
                    {file.lines}L
                  </span>
                </button>
              );
            })}
          </div>
        </aside>

        <section className="lg:col-span-8 rounded-xl border border-slate-800 bg-slate-900/80 flex flex-col overflow-hidden max-h-[70vh]">
          <div className="px-4 py-2.5 border-b border-slate-800 flex items-center justify-between gap-2 bg-slate-900">
            <span dir="ltr" className="font-mono text-xs text-amber-300 truncate">
              {activeFile?.path}
            </span>
            <button
              type="button"
              onClick={handleCopy}
              className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-800 hover:bg-slate-700 px-3 py-1.5 text-xs text-slate-200 transition-colors"
            >
              {copied ? (
                <>
                  <Check className="w-3.5 h-3.5 text-emerald-400" />
                  تم النسخ
                </>
              ) : (
                <>
                  <Copy className="w-3.5 h-3.5" />
                  نسخ الكود
                </>
              )}
            </button>
          </div>
          <pre
            dir="ltr"
            className="flex-1 overflow-auto p-4 text-xs font-mono leading-relaxed text-slate-200 bg-slate-950/70"
          >
            <code>{activeFile?.content}</code>
          </pre>
        </section>
      </main>
    </div>
  );
}
